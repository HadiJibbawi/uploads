-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 05, 2021 at 11:25 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `elections`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `id` int(11) NOT NULL,
  `person_id` int(11) DEFAULT NULL,
  `mantaka_id` int(11) DEFAULT NULL,
  `hay` varchar(100) DEFAULT NULL,
  `street` varchar(100) DEFAULT NULL,
  `building` varchar(100) DEFAULT NULL,
  `floor` varchar(3) DEFAULT NULL,
  `phone` int(11) DEFAULT NULL,
  `residency_type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`id`, `person_id`, `mantaka_id`, `hay`, `street`, `building`, `floor`, `phone`, `residency_type_id`) VALUES
(1, 1, 1, '', '', '', '', 0, 2),
(2, 2, 2, '', '', '', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `certificate_type`
--

CREATE TABLE `certificate_type` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `entimaa`
--

CREATE TABLE `entimaa` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `entimaa`
--

INSERT INTO `entimaa` (`id`, `name`) VALUES
(1, 'حركي(ة)'),
(2, 'مؤيد(ة)'),
(3, 'مستقل(ة)'),
(4, 'مناهض(ة)'),
(5, 'حزبي(ة)'),
(6, 'مؤيد(ة) لحزب');

-- --------------------------------------------------------

--
-- Table structure for table `kadaa`
--

CREATE TABLE `kadaa` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `mohafaza_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kadaa`
--

INSERT INTO `kadaa` (`id`, `name`, `mohafaza_id`) VALUES
(7, 'المتن', 2),
(8, 'بعبدا', 2),
(9, 'عاليه', 2),
(10, 'الشوف', 2),
(11, 'جبيل', 9),
(12, 'كسروان', 9),
(13, 'زحلة', 3),
(14, 'البقاع الغربي', 3),
(15, 'راشيا', 3),
(16, 'الهرمل', 4),
(17, 'بعلبك', 4),
(18, 'طرابلس', 7),
(19, 'زغرتا-الزاوية', 7),
(20, 'بشري', 7),
(21, 'البترون', 7),
(22, 'الكورة', 7),
(23, 'الضنية', 7),
(24, 'عكار', 8),
(25, 'صيدا', 6),
(26, 'صور', 6),
(27, 'جزين', 6),
(28, 'النبطية', 5),
(29, 'حاصبيا', 5),
(30, 'مرجعيون', 5),
(31, 'بنت جبيل', 5),
(32, 'بيروت', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mantaka`
--

CREATE TABLE `mantaka` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `kadaa` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mantaka`
--

INSERT INTO `mantaka` (`id`, `name`, `kadaa`) VALUES
(1, 'النبطية', 28),
(2, 'رياق', 13);

-- --------------------------------------------------------

--
-- Table structure for table `mazhab`
--

CREATE TABLE `mazhab` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mazhab`
--

INSERT INTO `mazhab` (`id`, `name`) VALUES
(1, 'السنّة'),
(2, 'الشيعة'),
(3, 'العلوييون'),
(4, 'الموارنة'),
(5, 'الروم الأرثوذكس'),
(6, 'الروم الكاثوليك'),
(7, 'الأرمن الأرثوذكس'),
(8, 'الأرمن الكاثوليك'),
(9, 'الدروز'),
(10, 'مسلم'),
(11, 'مسيحي'),
(12, 'أرمني');

-- --------------------------------------------------------

--
-- Table structure for table `mohafaza`
--

CREATE TABLE `mohafaza` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mohafaza`
--

INSERT INTO `mohafaza` (`id`, `name`) VALUES
(1, 'بيروت'),
(2, 'جبل لبنان'),
(3, 'البقاع'),
(4, 'بعلبك-الهرمل'),
(5, 'النبطية'),
(6, 'الجنوب'),
(7, 'الشمال'),
(8, 'عكار'),
(9, 'كسروان-جبيل');

-- --------------------------------------------------------

--
-- Table structure for table `movement_type`
--

CREATE TABLE `movement_type` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `movement_type`
--

INSERT INTO `movement_type` (`id`, `name`) VALUES
(1, 'شخصي'),
(2, 'بنزين'),
(3, 'نقل عام');

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `mother_name` varchar(150) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `entimaa_id` int(11) DEFAULT NULL,
  `entimaa_side` varchar(100) DEFAULT NULL,
  `mazhab_id` int(11) DEFAULT NULL,
  `movement_id` int(11) DEFAULT NULL,
  `wasika_id` int(11) DEFAULT NULL,
  `contact_name` varchar(150) DEFAULT NULL,
  `contact_phone` int(11) DEFAULT NULL,
  `rakm_sijil` int(11) DEFAULT NULL,
  `is_edited` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`id`, `first_name`, `middle_name`, `last_name`, `mother_name`, `birthday`, `entimaa_id`, `entimaa_side`, `mazhab_id`, `movement_id`, `wasika_id`, `contact_name`, `contact_phone`, `rakm_sijil`, `is_edited`) VALUES
(1, '           هادي', '           محمد', '           الجباوي', '        يزبك هيام', '1994-11-02', 1, '           حركة أمل', 2, 1, 1, 'علي ضاهر', 71717171, 11, 0),
(2, 'علي', 'سلمان', 'ضاهر', 'فاطمة', '1980-12-12', 1, 'حركة أمل', 2, 3, 2, 'هادي الجباوي', 81818181, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `residency_type`
--

CREATE TABLE `residency_type` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `residency_type`
--

INSERT INTO `residency_type` (`id`, `name`) VALUES
(1, 'داخل البلدة'),
(2, 'خارج البلدة'),
(3, 'مغترب');

-- --------------------------------------------------------

--
-- Table structure for table `study`
--

CREATE TABLE `study` (
  `id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `certificate_type` varchar(200) DEFAULT NULL,
  `major` varchar(300) DEFAULT NULL,
  `study_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `study_status`
--

CREATE TABLE `study_status` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `study_status`
--

INSERT INTO `study_status` (`id`, `name`) VALUES
(1, 'يتابع تحصيله العلمي'),
(2, 'غير متعلم'),
(3, 'أنهى تحصيله العلمي');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(30) NOT NULL,
  `role` varchar(20) DEFAULT NULL,
  `mantaka_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `mantaka_id`) VALUES
(1, 'admin', 'admin', 'ADM', 2),
(2, 'hadi', 'hadi', 'DE', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wasika_type`
--

CREATE TABLE `wasika_type` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wasika_type`
--

INSERT INTO `wasika_type` (`id`, `name`) VALUES
(1, 'بطاقة هوية'),
(2, 'جواز سفر'),
(3, 'لا يوجد');

-- --------------------------------------------------------

--
-- Table structure for table `work`
--

CREATE TABLE `work` (
  `id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `work_status_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `work_status`
--

CREATE TABLE `work_status` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `work_status`
--

INSERT INTO `work_status` (`id`, `name`) VALUES
(1, 'عسكري'),
(2, 'رجل دين'),
(3, 'وظيفة'),
(4, 'مهنة'),
(5, 'صنعة'),
(6, 'لا يعمل');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`id`),
  ADD KEY `address_mantaka` (`mantaka_id`),
  ADD KEY `address_person` (`person_id`),
  ADD KEY `address_residency` (`residency_type_id`);

--
-- Indexes for table `certificate_type`
--
ALTER TABLE `certificate_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `entimaa`
--
ALTER TABLE `entimaa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kadaa`
--
ALTER TABLE `kadaa`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kadaa_mohafaza` (`mohafaza_id`);

--
-- Indexes for table `mantaka`
--
ALTER TABLE `mantaka`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mantaka_kadaa` (`kadaa`);

--
-- Indexes for table `mazhab`
--
ALTER TABLE `mazhab`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mohafaza`
--
ALTER TABLE `mohafaza`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `movement_type`
--
ALTER TABLE `movement_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`id`),
  ADD KEY `person_entimaa` (`entimaa_id`),
  ADD KEY `person_mazhab` (`mazhab_id`),
  ADD KEY `person_movement` (`movement_id`),
  ADD KEY `person_wasika` (`wasika_id`);

--
-- Indexes for table `residency_type`
--
ALTER TABLE `residency_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `study`
--
ALTER TABLE `study`
  ADD PRIMARY KEY (`id`),
  ADD KEY `study_certificate` (`certificate_type`),
  ADD KEY `study_status` (`study_status`),
  ADD KEY `study_person` (`person_id`);

--
-- Indexes for table `study_status`
--
ALTER TABLE `study_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_mantaka` (`mantaka_id`);

--
-- Indexes for table `wasika_type`
--
ALTER TABLE `wasika_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `work`
--
ALTER TABLE `work`
  ADD PRIMARY KEY (`id`),
  ADD KEY `work_status` (`work_status_id`),
  ADD KEY `work_person` (`person_id`);

--
-- Indexes for table `work_status`
--
ALTER TABLE `work_status`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `certificate_type`
--
ALTER TABLE `certificate_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `entimaa`
--
ALTER TABLE `entimaa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `kadaa`
--
ALTER TABLE `kadaa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `mantaka`
--
ALTER TABLE `mantaka`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `mazhab`
--
ALTER TABLE `mazhab`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `mohafaza`
--
ALTER TABLE `mohafaza`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `movement_type`
--
ALTER TABLE `movement_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `person`
--
ALTER TABLE `person`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `residency_type`
--
ALTER TABLE `residency_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `study`
--
ALTER TABLE `study`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `study_status`
--
ALTER TABLE `study_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wasika_type`
--
ALTER TABLE `wasika_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `work`
--
ALTER TABLE `work`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `work_status`
--
ALTER TABLE `work_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `address_mantaka` FOREIGN KEY (`mantaka_id`) REFERENCES `mantaka` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `address_person` FOREIGN KEY (`person_id`) REFERENCES `person` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `address_residency` FOREIGN KEY (`residency_type_id`) REFERENCES `residency_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `kadaa`
--
ALTER TABLE `kadaa`
  ADD CONSTRAINT `kadaa_mohafaza` FOREIGN KEY (`mohafaza_id`) REFERENCES `mohafaza` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `mantaka`
--
ALTER TABLE `mantaka`
  ADD CONSTRAINT `mantaka_kadaa` FOREIGN KEY (`kadaa`) REFERENCES `kadaa` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `person`
--
ALTER TABLE `person`
  ADD CONSTRAINT `person_entimaa` FOREIGN KEY (`entimaa_id`) REFERENCES `entimaa` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `person_mazhab` FOREIGN KEY (`mazhab_id`) REFERENCES `mazhab` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `person_movement` FOREIGN KEY (`movement_id`) REFERENCES `movement_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `person_wasika` FOREIGN KEY (`wasika_id`) REFERENCES `wasika_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `study`
--
ALTER TABLE `study`
  ADD CONSTRAINT `study_person` FOREIGN KEY (`person_id`) REFERENCES `person` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `study_status` FOREIGN KEY (`study_status`) REFERENCES `study_status` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `user_mantaka` FOREIGN KEY (`mantaka_id`) REFERENCES `mantaka` (`id`);

--
-- Constraints for table `work`
--
ALTER TABLE `work`
  ADD CONSTRAINT `work_person` FOREIGN KEY (`person_id`) REFERENCES `person` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `work_status` FOREIGN KEY (`work_status_id`) REFERENCES `work_status` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
