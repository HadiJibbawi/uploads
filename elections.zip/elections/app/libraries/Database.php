<?php

/*
 * PDO Database Class
 * Connect to database
 * Create prepared statements
 * Bind Values
 * Return rows and results
 */

class Database
{
    private $host = DB_HOST;
    private $user = DB_USER;
    private $pass = DB_PASS;
    private $dbname = DB_NAME;
    private $charset = CHARSET;

    private $dbh;
    private $stmt;
    private $error;

    public function __construct()
    {

        //set DSN (Data Source Name)
        // this can be modified to take the host and database as parameters
        $dsn = 'mysql:host=' . $this->host . ';dbname=' . $this->dbname .';charset=' . $this->charset;
        $options = array(
            PDO::ATTR_PERSISTENT => true,
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        );

        //create new PDO instance
        try {
            $this->dbh = new PDO($dsn, $this->user, $this->pass, $options);
        } catch (PDOException $e) {
            $this->error = $e->getMessage();
            echo $this->error;
        }
    }

    //prepare statement with query
    public function query($sql)
    {
        $this->stmt = $this->dbh->prepare($sql);
    }

    //bind values
    public function bind($param, $value, $type = null)
    {
        if (is_null($type)) {
            switch (true) {
                case is_int($value):
                    $type = PDO::PARAM_INT;
                    break;
                case is_bool($value):
                    $type = PDO::PARAM_BOOL;
                    break;
                case is_null($value):
                    $type = PDO::PARAM_NULL;
                    break;
                default:
                    $type = PDO::PARAM_STR;
            }
        }
        $this->stmt->bindValue($param, $value, $type);
    }

    //Execute the prepared statement
    public function execute()
    {
        return $this->stmt->execute();
    }

    //Get result set as array of objects
    public function resultSet()
    {
//        var_dump($this->stmt);
        $this->stmt->execute();
        return $this->stmt->fetchAll(PDO::FETCH_OBJ);
    }

    //get single record as object
    public function single()
    {
        $this->stmt->execute();
        return $this->stmt->fetch(PDO::FETCH_OBJ);
    }

    //get row count
    public function rowCount(){
        return $this->stmt->rowCount();
    }

    public function getLastInsertedId(){
        return $this->dbh->lastInsertId();
    }

    public function updateTable($table,$columns,$primaryKeyName,$primaryKeyValue,$debug = false)
    {

        if (sizeof($columns) > 0) {
            $query = "UPDATE " . $table . ' SET ';

            foreach ($columns as $key => $value) {
                $query .= '`' . $key . '` = \'' . $value . '\' , ';
            }
            $query =  substr($query, 0, -2);
            $query .= 'WHERE `'. $primaryKeyName .'` = :primaryKeyValue';
            if($debug == true){
              return $query;
            }
            $this->query($query);
            $this->bind(':primaryKeyValue',$primaryKeyValue);
            // Execute
            if ($this->execute()) {
                return true;
            }
            else {
                return false;
            }

        }
        else {
            return 'empty columns';
        }
    }
    public function insertIntoTable($table,$columns,$debug = false)
    {

        if (sizeof($columns) > 0) {
            $query = "INSERT INTO " . $table . ' ( ';

            foreach ($columns as $key => $value) {
                $query .= '`' . $key . '`,';
            }
            $query =  substr($query, 0, -1);
            $query .= ') VALUES (';
            foreach ($columns as $key => $value) {
                $query .= ' :' . $key . ',';
            }
            $query =  substr($query, 0, -1);
            $query .= ');';
            if($debug == true){
                return $query;
                die;
            }
            $this->query($query);
           foreach ($columns as $key => $value){
               $this->bind(':'.$key,$value);
           }
            // Execute
            if ($this->execute()) {
                return true;
            }
            else {
                return false;
            }

        }
        else {
            return 'empty columns';
        }
    }

//    public function hash($value){
//        //this function hashes the value using md5, it could be something else in the future
//        return md5($value);
//    }

}