<?php

define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','elections');
define('CHARSET','utf8');

//App Root
define('APPROOT', dirname(dirname(__FILE__)));
//File Root
define('FILEROOT', 'C:\\xampp\\htdocs\\elections\\public\\');
//URL Root
define('URLROOT','http://localhost/elections');
//define('URLROOT','http://localhost:8888/bdesign');
//define('URLROOT','http://192.168.1.102:8888/violet');
//App Logo URL
//define('APPLOGOURL','http://192.168.1.102:8888/violet/img/violet_logo.jpg');
define('APPLOGOURL','http://localhost/elections/img/baydoun.jpg');
//define('APPLOGOURL','http://localhost:8888/bdesign/img/bdesign.jpg');
//img Root Folder URL
//define('IMGROOTURL','http://192.168.1.102:8888/violet/img');
define('IMGROOTURL','http://localhost/elections/public/img');
//define('IMGROOTURL','http://localhost:8888/bdesign/public/img');
//App Logo Name
define('APPLOGONAME','baydoun.jpg');
//Site Name // this should be the site not framework
define('SITENAME','اللجنة المركزية للانتخابات النيابية');
//App Version
define('APPVERSION','1.0.0');
