<?php

class Login extends Controller
{
    private $loginModel;

    public function __construct()
    {
        $this->loginModel = $this->model('LoginModel');
    }
    public function index()
    {
        $data = ['title' => 'اللجنة المركزية للانتخابات النيابية', 'description' => 'Please login if you\'re an admin or else, please register'];
        $this->view('pages/index', $data);

    }

    public function login()
    {
        $data = ['title' => 'تسجيل الدخول', 'description' => 'تسجيل الدخول'];
        $template = [];
        $template['page_script'] = 'login';
        $this->view('admin/login', $data, $template);
    }

    public function logout(){
        session_destroy();
        header("location:" . URLROOT . "/login/login");
    }


    public function requests($request)
    {
        switch ($request) {


            default:
                echo "invalid request";
                break;
        }
    }
}