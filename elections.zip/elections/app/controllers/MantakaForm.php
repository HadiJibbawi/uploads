<?php

class MantakaForm extends Controller
{
    private $mantakaformModel;

    public function __construct()
    {
        $this->mantakaformModel = $this->model('MantakaFormModel');
    }

    //this function is here is the index root function
    public function index()
    {
        $data = ['title' => 'اللجنة المركزية للانتخابات النيابية', 'description' => 'Please login if you\'re an admin or else, please register'];
        $this->view('pages/index', $data);

    }

    public function mantakaform()
    {
        $data = ['title' => 'استمارة رقم 1', 'description' => 'نموذج استمارة رقم 1'];
        $template = [];
        $template['page_script'] = 'mantakaform';
        $this->view('admin/mantakaform', $data, $template);
    }

    private function addMantakaForm($mantaka)
    {

        return $this->mantakaformModel->addMantakaForm($mantaka);
    }

    private function updateRow($mantaka)
    {
        echo $this->mantakaformModel->updateRow($mantaka);
    }
    public function requests($request)
    {
        switch ($request) {
 
                case 'getAllIndividuals':
                    if (isset(func_get_args()[1])) {
                        $mn = func_get_args()[1];
                        $ela = func_get_args()[2];
                        $mantakaId= func_get_args()[3];
                        if (func_get_args()[4] == 'datatablesEncode') {
                            echo $this->datatables_encode($this->mantakaformModel->getAllIndividuals($mn,$ela,$mantakaId));
                        }
                        else {
                            echo $this->encode_json($this->mantakaformModel->getAllIndividuals());
                        }
                    }
                    else {
                        echo $this->encode_json($this->mantakaformModel->getAllIndividuals());
                    }
                    break;
                case 'getIndividuals':
                    echo $this->encode_json($this->mantakaformModel->getIndividuals());
                    break;        
                case 'getEntimaaTypes':
                    echo $this->encode_json($this->mantakaformModel->getEntimaaTypes());
                    break;
                case 'getWasikaTypes':
                    echo $this->encode_json($this->mantakaformModel->getWasikaTypes());
                    break;   
                case 'getMovementTypes':
                    echo $this->encode_json($this->mantakaformModel->getMovementTypes());
                    break; 
                case 'getKadaa':
                    echo $this->encode_json($this->mantakaformModel->getKadaa());
                    break;
                case 'getResidencyTypes':
                    echo $this->encode_json($this->mantakaformModel->getResidencyTypes());
                    break; 
                case 'getStudyStatuses':
                    echo $this->encode_json($this->mantakaformModel->getStudyStatuses());
                    break;
                case 'getWorkStatuses':
                    echo $this->encode_json($this->mantakaformModel->getWorkStatuses());
                    break; 
                case 'getMazhabTypes':
                    echo $this->encode_json($this->mantakaformModel->getMazhabTypes());
                    break;  
                case 'getMantakas':
                    echo $this->encode_json($this->mantakaformModel->getMantakas());
                    break;    
                case 'addMantakaForm':
                    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                        echo $this->addMantakaForm($_POST);
                    }
                    else {
                        echo 'invalid request data';
                    }
                    break; 
                    case 'updateRow':
                        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                            $this->updateRow($_POST);
                        }
                        else {
                            $this->mantakaform();
                        }
                        break;                                       
            default:
                echo "invalid request";
                break;
        }
    }
}

?>