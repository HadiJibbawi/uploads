<?php

class Users extends Controller
{
    public function __construct()
    {
        $this->userModel = $this->model('User');
    }

    //should load the form and handle it

    public function index()
    {
        $this->login();
    }

    public function register()
    {
        //Check for POST
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $name = $_POST['name'];
            $isEven = ($_POST['car_number'] == 'even') ? true : false;
            $this->userModel->registerCar($name, $isEven);
            flash('car_registered', 'Your car has been succesfully registered');
            $data = ['name' => ''];
            $this->view('users/register', $data);
        }
        else {
            //Init Data
            $data = ['name' => ''];
            //load view
            $this->view('users/register', $data);
        }
    }

    public function login($isauth = 'true')
    {
//        flash('login_success', 'You have succesfully logged in as ' . $_POST['username']);
        $tmpuser = new stdClass();
        $tmpuser->id = 'tmp';
        $tmpuser->userName = 'tmpname';
        $this->createUserSession($tmpuser);
        die;

        $template = [];
        $template['page'] = 'login';
        //Check for POST
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            $adminExists = $this->userModel->SearchAdminByUsername(['username' => $_POST['username']]);
            if ($adminExists) {
                $user = $this->userModel->verifyAdminLogin(['username' => $_POST['username'], 'password' => $_POST['password']]);
                if ($user) {
                    flash('login_success', 'You have succesfully logged in as ' . $_POST['username']);
                    $this->createUserSession($user);
                    redirect('mantakaform/mantakaform');
                }
                else {
                    $data = [
                        'username' => $_POST['username'],
                        'password' => '',
                        'username_err' => '',
                        'password_err' => 'Invalid password'
                    ];
                    //load view
                    $this->view('users/login', $data,$template);
                }
            }
            else {
                $data = [
                    'username' => '',
                    'password' => '',
                    'username_err' => 'User Does Not Exist',
                    'password_err' => ''
                ];
                //load view

                $this->view('users/login', $data,$template);
            }
        }
        elseif ($this->isLoggedIn()) {
            //go to the home page;
            redirect('pages/about');
        }
        else{
            if ($isauth != 'true'){
                flash('unauthorized', 'You must login first ','alert alert-danger');
            }
            //Init Data
            $data = [
                'username' => '',
                'email' => '',
                'password' => '',
                'username_err' => '',
                'email_err' => '',
                'password_err' => ''
            ];
            //load view
            $this->view('users/login', $data,$template);
        }
    }

    public function createUserSession($user)
    {
        $_SESSION['user_id'] = $user->id;
        $_SESSION['username'] = $user->userName;
        redirect('mantakaform/mantakaform');
    }

    public function logout()
    {
        unset($_SESSION['user_id']);
        session_destroy();
        redirect('users/login');
    }

    public function isLoggedIn()
    {
        if (isset($_SESSION['user_id'])) {
            return true;
        }
        else {
            return false;
        }
    }




    public function requests()
    {
        $reqParams = func_get_args();
        $request = $reqParams[0];
        switch ($request) {
            default:
                echo "invalid request";
                break;
        }
    }
}
