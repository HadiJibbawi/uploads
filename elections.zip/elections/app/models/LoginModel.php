<?php

class LoginModel
{
    private $db;

    public function __construct()
    {
        $this->db = new Database;
        if (!isset($_SESSION))
        session_start();
    }


}