<?php

class MantakaFormModel
{
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }

    public function getAllIndividuals($mn, $ela, $mantakaId)
    {
        $this->db->query('SELECT p.id as Id, p.first_name as firstName, p.middle_name as middleName, p.last_name as lastName, p.mother_name as motherName
                            ,p.birthday as birthday, m.name as mazhab, p.mazhab_id as mazhabId, trim(p.rakm_sijil) as rakmSijil, rt.name as residencyType, wt.name as wasikaType, mt.name as movementType, p.entimaa_side as entimaaSide, e.name as entimaaType
                            FROM person p
                            LEFT JOIN address ad on p.id = ad.person_id
                            LEFT JOIN entimaa e on p.entimaa_id = e.id
                            LEFT JOIN mazhab m on p.mazhab_id = m.id
                            LEFT JOIN residency_type rt on ad.residency_type_id = rt.id
                            LEFT JOIN wasika_type wt on p.wasika_id = wt.id
                            LEFT JOIN movement_type mt on p.movement_id = mt.id
                            LEFT JOIN mantaka mn on ad.mantaka_id = mn.id
                            WHERE p.rakm_sijil >= :mn and p.rakm_sijil <= :ela
                            and ad.mantaka_id = :mantakaId
                            and is_edited = 0');
        $this->db->bind(':mn',$mn);
        $this->db->bind(':ela', $ela);
        $this->db->bind(':mantakaId', $mantakaId);
        $individuals = $this->db->resultSet();
        return $individuals;
    }
    public function getIndividuals()
    {
        $this->db->query('SELECT p.id as Id, TRIM(p.first_name) as firstName, TRIM(p.middle_name) as middleName, TRIM(p.last_name) as lastName, TRIM(p.mother_name) as motherName, p.contact_name as contactName, p.contact_phone as contactPhone, mn.name as mantaka
        ,p.birthday as birthday, m.name as mazhab, trim(p.rakm_sijil) as rakmSijil, rt.id as residencyTypeId,rt.name as residencyType, wt.name as wasikaType, mt.name as movementType, p.entimaa_side as entimaaSide, e.name as entimaaType
, st.major as major, st.certificate_type as certificateType, sst.name as studyStatus            ,w.name as workName, ws.name as workType             
       
        FROM person p
        LEFT JOIN address ad on p.id = ad.person_id
        LEFT JOIN entimaa e on p.entimaa_id = e.id
        LEFT JOIN mazhab m on p.mazhab_id = m.id
        LEFT JOIN residency_type rt on ad.residency_type_id = rt.id
        LEFT JOIN wasika_type wt on p.wasika_id = wt.id
        LEFT JOIN movement_type mt on p.movement_id = mt.id
        LEFT JOIN mantaka mn on ad.mantaka_id = mn.id
        LEFT JOIN study st on p.id = st.person_id
        LEFT JOIN study_status sst on st.study_status = sst.id
        LEFT JOIN work w on p.id = w.person_id
        LEFT  JOIN work_status ws on w.work_status_id = ws.id
         where is_edited = 0');
        
        $individuals = $this->db->resultSet();
        return $individuals;
    }
    public function updateRow($mantaka)
    {   
        $Id = $mantaka['Id'];
       /*  $firstName = $mantaka['firstName'];
        $middleName = $mantaka['middleName'];
        $lastName = $mantaka['lastName'];
        $motherName = $mantaka['motherName'];
        $mazhab = $mantaka['mazhab'];
        $rakmSijil = $mantaka['rakmSijil']; */
        $residencyType = $mantaka['residencyType'];
        $wasikaType = $mantaka['wasikaType'];
        $movementType = $mantaka['movementType'];
        $entimaaSide = $mantaka['entimaaSide']; 
        $entimaaType = $mantaka['entimaaType'];
        
        $this->db->query('UPDATE person
                          SET movement_id = :movementType,
                          entimaa_side = :entimaaSide,
                          is_edited = 1
                          WHERE id = :Id');
        
       
        //$this->db->bind(':wasikaType', $wasikaType);
        $this->db->bind(':movementType', $movementType);
        $this->db->bind(':entimaaSide', $entimaaSide);
        //$this->db->bind(':entimaaType', $entimaaType);
        $this->db->bind(':Id', $Id);
       return  $this->db->execute();
       
    }

    public function getEntimaaTypes(){
        $this->db->query('SELECT DISTINCT id AS Id, name AS title from entimaa');
        return $this->db->resultSet();
    }

    public function getMantakas(){
        $this->db->query('SELECT DISTINCT id AS id, name As title from mantaka');
        return $this->db->resultSet();
    }

    public function getWasikaTypes(){
        $this->db->query('SELECT DISTINCT id AS Id, name AS title from wasika_type');
        return $this->db->resultSet();
    }

    public function getMovementTypes(){
        $this->db->query('SELECT DISTINCT id AS Id, name AS title from movement_type');
        return $this->db->resultSet();
    }

    public function getKadaa(){
        $this->db->query('SELECT DISTINCT id AS Id, name as title FROM kadaa');
        return $this->db->resultSet();
    }

    public function getResidencyTypes(){
        $this->db->query('SELECT DISTINCT id AS Id, name AS title from residency_type');
        return $this->db->resultSet();
    }

    public function getStudyStatuses(){
        $this->db->query('SELECT DISTINCT id AS Id, name AS title from study_status');
        return $this->db->resultSet();
    }

    public function getWorkStatuses(){
        $this->db->query('SELECT DISTINCT id AS Id, name AS title from work_status');
        return $this->db->resultSet();
    }

    public function getMazhabTypes(){
        $this->db->query('SELECT DISTINCT id AS Id, name AS title from mazhab');
        return $this->db->resultSet();
    }

    public function addMantakaForm($mantaka)
    {
        //PERSONAL iNFO
          $firstName = $mantaka['firstName'];
          $middleName = $mantaka['middleName'];
          $lastName = $mantaka['lastName'];
          $motherName = $mantaka['motherName']; 
          $birthday = $mantaka['birthday'];
          $mazhabId = $mantaka['mazhabId'];
          $rakmSijil =  $mantaka['rakmSijil']; 
          $contactName = $mantaka['contactName'];
          $contactPhone = $mantaka['contactPhone'];
        //ADDRESS INFO
          $mantakaId = $mantaka['mantakaId'];
          $hay = $mantaka['hay'];
          $street = $mantaka['street'];
          $building = $mantaka['building'];
          $floor = $mantaka['floor'];
          $phone = $mantaka['phone'];
          $residencyTypeId = $mantaka['residencyTypeId'];
        //PROGRESS INFO
          $major = $mantaka['major'];
          $certificateTypeId = $mantaka['certificateTypeId'];
          $studyStatusId = $mantaka['studyStatusId'];
          $workName = $mantaka['workName'];
          $workTypeId = $mantaka['workTypeId'];
        //ELECTIONS INFO
          $entimaaId = $mantaka['entimaaId'];
          $entimaaName = $mantaka['entimaaName'];
          $movementId = $mantaka['movementId'];
          $wasikaId = $mantaka['wasikaId'];

        $this->db->query('INSERT INTO `person`( `first_name`, `middle_name`, `last_name`, `mother_name`,
         `birthday`, `entimaa_id`, `entimaa_side`, `mazhab_id`, `movement_id`, `wasika_id`, `contact_name`, `contact_phone`, `rakm_sijil`) 
        VALUES (:firstName,:middleName,:lastName,:motherName,
        :birthday,:entimaaId,:entimaaName,:mazhabId,:movementId,:wasikaId,:contactName,:contactPhone,:rakmSijil)');
        $this->db->bind(':firstName', $firstName);
        $this->db->bind(':middleName', $middleName);
        $this->db->bind(':lastName', $lastName);
        $this->db->bind(':motherName', $motherName);
        $this->db->bind(':birthday', $birthday);
        $this->db->bind(':entimaaId', $entimaaId);
        $this->db->bind(':entimaaName', $entimaaName);
        $this->db->bind(':mazhabId', $mazhabId);
        $this->db->bind(':movementId', $movementId);
        $this->db->bind(':wasikaId', $wasikaId);
        $this->db->bind(':contactName', $contactName);
        $this->db->bind(':contactPhone', $contactPhone);
        $this->db->bind(':rakmSijil', $rakmSijil); 
   
        if ($this->db->execute() == 1) {
            $this->db->query('INSERT INTO `address`(`person_id`, `mantaka_id`, `hay`, `street`, `building`, `floor`, `phone`, `residency_type_id`) 
            VALUES ((SELECT max(id)  from person),:mantakaId,:hay,:street,:building,:floor,:phone,:residencyTypeId)');
            $this->db->bind(':mantakaId', $mantakaId);
            $this->db->bind(':hay', $hay);
            $this->db->bind(':street', $street);
            $this->db->bind(':building', $building);
            $this->db->bind(':floor', $floor);
            $this->db->bind(':phone', $phone);
            $this->db->bind(':residencyTypeId', $residencyTypeId);
            $this->db->execute();

             $this->db->query('INSERT INTO `study`(`person_id`, `certificate_type`, `major`, `study_status`) 
            VALUES ((SELECT MAX(id) FROM person),:certificateTypeId,:major,:studyStatusId)');
            $this->db->bind(':certificateTypeId', $certificateTypeId);
            $this->db->bind(':major', $major);
            $this->db->bind(':studyStatusId', $studyStatusId);
            $this->db->execute(); 

            $this->db->query('INSERT INTO `work`( `person_id`, `work_status_id`, `name`) VALUES ((SELECT MAX(id) FROM person),:workTypeId,:workName)');
            $this->db->bind(':workTypeId', $workTypeId);
            $this->db->bind(':workName', $workName);
            
            if ($this->db->execute() == 1 )
                return 1;
            return 0;    
        }
        return 0;

    }
}