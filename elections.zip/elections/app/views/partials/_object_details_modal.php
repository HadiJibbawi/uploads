<?php


if (!isset($pane_properties)) {
    die('invalid small pane parameters');
}
if (!isset($pane_properties['colsize'])) {
    $pane_properties['colsize'] = 'col-3';
}
if (!isset($pane_properties['modalSizeClass'])) {
    $pane_properties['modalSizeClass'] = '';
}
if (!isset($pane_properties['margin-top'])) {
    $pane_properties['margin-top'] = 'mt-5';
}
if (!isset($pane_properties['margin-left'])) {
    $pane_properties['margin-left'] = 'ml-5';
}
if (!isset($pane_properties['itemName'])) {
    die('need to supply item name');
}
if (!isset($pane_properties['emptyValueCheck'])) {
    die('need to supply empty value check for knockout');
}
if (!isset($pane_properties['formName'])) {
    die('need to supply form name');
}
if (!isset($pane_properties['modalTitle'])) {
    $pane_properties['modalTitle'] = 'Edit ' . $pane_properties['itemName'];
}
if (!isset($pane_properties['modalId'])) {
    $pane_properties['modalId'] = 'edit_' . $pane_properties['itemName'] . '_modal';
}
$emptyValueCheck = '<!-- ko if: ' . $pane_properties['emptyValueCheck'] . '-->';
$emptyValueCheckFinish = '<!-- /ko -->';
$values = $pane_properties['values'];
?>
<div id="<?php echo $pane_properties['modalId'] ?>" class="modal show" style="z-index: 1110;">
    <div class="modal-dialog <?php echo $pane_properties['modalSizeClass']?>" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <?php echo $emptyValueCheck ?>
                <h5 class="modal-title" id="<?php echo $pane_properties['modalId'] ?>_label" data-bind="text :<?php echo $pane_properties['modalTitle'] ?>"></h5>
                <?php echo $emptyValueCheckFinish ?>
                <button type="button" class="close" data-dismiss="modal" data-bind="click:function(){$('#<?php echo $pane_properties['modalId'] ?>').modal('hide')}">
                    <span>×</span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo $emptyValueCheck ?>
                <h3 style="height: 3rem;" class="" data-bind="text :<?php echo $pane_properties['title'] ?>.charAt(0).toUpperCase() + <?php echo $pane_properties['title'] ?>.slice(1)"></h3>
                <div style="position: relative;height: 90%;border-style: solid;padding: 1rem 1rem 8rem 1rem;border-color: lightgrey;border-width: 0.05rem;">
                    <form id="<?php echo $pane_properties['formName'] ?>">
                        <?php

                        foreach ($values as $value) {
                            if (isset($value['noNewRow'])) {
                                $noNewRow = true;
                            }
                            else {
                                $noNewRow = false;
                            }
                            if (isset($value['oldRow'])) {
                                $oldRow = true;
                            }
                            else {
                                $oldRow = false;
                            }
                            if (isset($value['colSize'])) {
                                $colSize = $value['colSize'];
                            }
                            else {
                                $colSize = 'col-12';
                            }
                            $randomNum = random_int(1, 10000);
                            $randomId = $value['name'] . $randomNum;
                            $name = $value['name'];
                            if (isset($value['placeholder'])) {
                                $placeholder = $value['placeholder'];
                            }
                            else {
                                $placeholder = ucfirst($value['name']);
                            }

                            $required = $value['required'] == 'false' ? '' : 'required';
                            if ($required){
                                $requiredString = '*';
                            }
                            else{
                                $requiredString = '';
                            }
                            $label = '<label for="' . $randomId . '" style="font-size: 1rem;font-weight: bold;">' . ucfirst($value['name']) . ' :'.$requiredString.'</label>';
                            if (isset($value['enable'])) {
                                if ($value['enable'] == 'true') {
                                    $randomIdEnable = $randomId . 'check';
                                    $enableHandle = $value['enableHandle'];
                                    $labelEnable = '<label for="' . $randomIdEnable . '" style="font-size: 1rem;font-weight: bold">Enable :</label>';
                                    $checkBoxEnable = '<input id="' . $randomIdEnable . '" type="checkbox" data-bind="checked: ' . $enableHandle . '">';
                                    $enableString = "<div>\n" . $labelEnable . "\n" . $checkBoxEnable . "\n</div>";
                                    $enableDataBindString = ',enable: ' . $enableHandle;
                                }
                                else {
                                    if (isset($value['enableHandle'])) {
                                        $enableDataBindString = ',enable: ' . $value['enableHandle'];
                                    }
                                    else {
                                        $enableDataBindString = '';
                                    }
                                    $enableString = '';
                                }
                            }
                            else {
                                $enableDataBindString = '';
                                $enableString = '';
                            }
                            if ($value['type'] != 'select' && $value['type'] != 'button') {
                                $type = $value['type'];
                                $textInput = $value['value'];
                                $input = '<input  id="' . $randomId . '" type="' . $type . '" name="' . $name . '"  data-bind="textInput : ' . $textInput . ' ' . $enableDataBindString . '" placeholder="' . $placeholder . '"  class="form-control mb-4 " ' . $required . ' />';
                            }
                            elseif ($value['type'] == 'button') {
                                if (isset($value['buttonClass'])) {
                                    $buttonClass = $value['buttonClass'];
                                }
                                else {
                                    $buttonClass = 'btn btn-primary';
                                }
                                if (isset($value['buttonClick'])) {
                                    $buttonClick = $value['buttonClick'];
                                }
                                else {
                                    $buttonClick = '';
                                }
                                if (isset($value['attributes'])){
                                    $attributes = ' '.$value['attributes']. ' ';
                                }
                                else{
                                    $attributes = '';
                                }
                                $input = '<button type="button" '.$attributes.' class="' . $buttonClass . '" id="' . $randomId . '" data-bind="click:' . $buttonClick . ' ' . $enableDataBindString . '">' . ucfirst($value['name']) . '</button>';

                            }
                            else {
                                $options = $value['options'];
                                //this is the value of the javascript object to hold the chosen value
                                $valueOptions = $value['value'];
                                $caption = $value['caption'];

                                if (isset($value['optionsValue'])) {
                                    $optionsValue = $value['optionsValue'];
                                    $optionsValueString = ',optionsValue : \'' . $optionsValue . '\'';
                                    if (isset($value['optionsText'])) {
                                        $optionsText = $value['optionsText'];
                                        $optionsValueString .= ',optionsText:\'' . $optionsText . '\'';
                                    }
                                }
                                else {
                                    $optionsValueString = '';
                                }
                                $input = '<select class="form-control mb-4" name="' . $name . '" id="' . $randomId . '" data-bind="options : ' . $options . ',value:' . $valueOptions . $optionsValueString . ',optionsCaption:\'' . $caption . '\' ' . $enableDataBindString . ' " '.$required.'></select>';
                            }
                            if (!$oldRow) {
                                echo $emptyValueCheck;
                                echo '<div class="row">';
                            }
                            echo '<div class="' . $colSize . '">';
                            echo $label;
                            echo $enableString;
                            echo $input;
                            echo '</div>';
                            if (!$noNewRow) {
                                echo '</div>';
                                echo $emptyValueCheckFinish;
                            }
                        }
                        $resetValuesFunction = $pane_properties['resetFunction'];
                        $submitValuesFunction = $pane_properties['submitFunction'];
                        ?>
                        <div style="position: absolute;bottom: 1rem;width: 100%;">
                            <div class="row justify-content-around">
                                <div style="position: absolute;bottom: 0.5rem;left: 4%; width: 25%;">
                                    <button type="button" class="btn btn-secondary" style="width: 100%;"  id="clear<?php echo ucfirst($pane_properties['title']); ?>" data-bind="click:<?php echo $resetValuesFunction ?>">Reset</button>
                                </div>
                                <div style="position: absolute;bottom: 0.5rem;right:10%;width: 25%;">
                                    <button type="button" class="btn btn-success" style="width: 100%;" id="submit<?php echo ucfirst($pane_properties['title']); ?>" data-bind="click:<?php echo $submitValuesFunction ?>">Submit</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- /ko -->
            </div>
        </div>
    </div>
<?php //echo $emptyValueCheckFinish; ?>