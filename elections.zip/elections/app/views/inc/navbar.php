

<nav class="navbar navbar-expand-sm bg-success navbar-dark mb-3 fixed-top">
<div class="collapse navbar-collapse ">

    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

<!-- Links -->
  <ul class="navbar-nav ml-auto">
    <li class="nav-item ">
      <a class="nav-link" href="#">استمارة 3</a>
    </li>
    <li class="nav-item">
      <a class="nav-link"  href="#">استمارة 2</a>
    </li>
    <li class="nav-item">
        <?php if(isset($_SESSION['uname'])) {?>
            <a class="nav-link "  href="<?php echo URLROOT; ?>/mantakaform/mantakaform">استمارة 1</a>
        <?php }
        else{?>
            <a class="nav-link "  href="<?php echo URLROOT; ?>/login/logout">استمارة 1</a>
       <?php } ?>
    </li>
      <li class="nav-item">
          <?php if(!isset($_SESSION['uname'])) {?>
              <a class="nav-link "  href="<?php echo URLROOT; ?>/login/login">تسجيل الدخول</a>
          <?php }
          else{?>
              <a class="nav-link "  href="<?php echo URLROOT; ?>/login/logout">تسجيل الخروج</a>
          <?php } ?>
      </li>
  </ul>
  <!-- Brand/logo -->
  <a class="navbar-brand ml-auto" href="<?php echo URLROOT; ?>"><?php echo SITENAME; ?></a>
  
   </div>
 
</nav> 