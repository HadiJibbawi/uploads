<?php
//if (!isset($_SESSION['user_id'])) {
//    if (isset($template['page'])) {
//        if ($template['page'] != 'login')
//            header('location: ' . URLROOT . '/users/login/false');
//    }
//    else{
//        header('location: ' . URLROOT . '/users/login/false');
//    }
//} ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo URLROOT; ?>/public/img/favicon.ico"/>
    <link rel="stylesheet" href="<?php echo URLROOT; ?>/public/css/bootstrap.css">
    <!--    <link href="--><?php //echo URLROOT; ?><!--/public/css/font-awesome.min.css" rel="stylesheet">-->
    <link href="<?php echo URLROOT; ?>/public/helpers/fontawesome/css/all.css" rel="stylesheet">
    <link href="<?php echo URLROOT; ?>/public/css/toastr.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/datatables/datatables.min.css"/>
    <link rel="stylesheet" href="<?php echo URLROOT; ?>/public/css/style.css">
    <?php
    if (isset($template['stylesheet'])) {
        if (!empty($template['stylesheet'])) {
            echo '<link rel="stylesheet" type="text/css" href="' . URLROOT . '/public/css/pages/' . $template['stylesheet'] . '.css' . '">';
        }
    }
    ?>

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <title><?php echo SITENAME; ?></title>

</head>
<body>
<?php require APPROOT . '/views/inc/navbar.php'; ?>
<div class="container-fluid mt-5">