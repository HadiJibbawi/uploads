<?php

?>

<div class="container-fluid" style="margin-bottom: 5rem">
    <div class="row justify-content-around">


        <?php
        $pane_properties = [];
        $pane_properties['emptyValueCheck'] = '$root.currentUser().userName != \'\'';
        $pane_properties['formName'] = 'editCurrentUserForm';
        $pane_properties['title'] = '$root.currentUser().name';
        $pane_properties['resetFunction'] = '$root.clearCurrentUserEdits';
        $pane_properties['submitFunction'] = '$root.submitCurrentUserEdits';
        // le" data-bind="options : ,value:$root.currentUser().roleId,optionsValue : 'id',optionsText:'name',optionsCaption:'Choose Role'"></select>

        $values = [
            ['title' => 'userName', 'name' => 'userName', 'value' => '$root.currentUser().userName', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
            ['title' => 'name', 'name' => 'name', 'value' => '$root.currentUser().name', 'type' => 'text', 'enable' => 'false', 'required' => 'false'],
            ['title' => 'role', 'name' => 'role', 'value' => '$root.currentUser().roleId', 'optionsText' => 'name', 'optionsValue' => 'id', 'caption' => 'Choose Role', 'options' => '$root.userRoles', 'type' => 'select', 'enable' => 'false', 'required' => 'false'],
            ['title' => 'Password', 'name' => 'password','noNewRow'=>'true','colSize'=>'col-6', 'value' => '$root.currentUser().password', 'type' => 'password', 'enable' => 'true', 'enableHandle' => '$root.currentUser().changePass', 'required' => 'true'],
            ['title' => 'DELETE', 'name' => 'delete','oldRow'=>'true','colSize'=>'col-6','buttonClass'=>'btn btn-danger w-100', 'type' => 'button','enable'=>'true','buttonClick'=>'$root.deleteCurrentUser', 'enableHandle' => '$root.currentUser().deleteUser', 'required' => 'true']
        ];
        $pane_properties['values'] = $values;
        include(APPROOT . '/views/partials/_small_object_details_pane.php');
        ?>

        <div class="col-8">
            <div id="users_table_container" class="col-11">
                <?php
                $table_columns = ['Username', 'Name', "Role"];
                $table_properties = ["tableId" => "datatable_users", "title" => 'Users', 'title-size' => 'h3'];
                include(APPROOT . '/views/partials/_datatable_full_generic.php');
                ?>
            </div>
        </div>
    </div>
</div>

<!--Add User Modal-->
<div id="new_user_modal" class="modal show" style="z-index: 1110;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="new_user_modal_label">New User</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="addUserForm" autocomplete="off">
                    <div class="form-group">
                        <label for="new_user_username">User Name</label>
                        <input id="new_user_username" autocomplete="new-password" name="username" data-bind="textInput :  $root.newUserUsername,attr : {'placeholder' : 'UserName'}" class="form-control" type="text" required/>
                        <label for="new_user_name">Name</label>
                        <input id="new_user_name" autocomplete="new-password" name="name" data-bind="textInput :  $root.newUserName,attr : {'placeholder' : 'Name'}" class="form-control" type="text" required/>
                        <label for="new_user_password">Password</label>
                        <input id="new_user_password" autocomplete="new-password" name="password" pattern=".{0}|.{8,}" data-bind="textInput :  $root.newUserPassword,attr : {'placeholder' : 'Password should be 8 or more characters'}" class="form-control passwordcheck" type="password" required/>
                        <label for="new_user_role">Role</label>
                        <select class="form-control" name="category" id="new_user_role" data-bind="options : $root.userRoles,value:$root.newUserRoleId,optionsValue : 'id',optionsText:'name',optionsCaption:'Choose Role'" required></select>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary mr-auto" data-bind="click:$root.clearNewUserModal">Clear</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button id="save_new_user_btn" type="button" data-bind="click:$root.addUser" class="btn btn-info">Save changes</button>
                    </div>
                </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>