<?php


if(!isset($_SESSION['uname'])){?>

<?php }

else
    header("location:" . URLROOT . '/mantakaform/mantakaform');


if(!isset($_SESSION))
    session_start();
$host = DB_HOST;
$username = DB_USER;
$password = DB_PASS;
$database = DB_NAME;
$message = "";
try
{
    $connect = new PDO("mysql:host=$host; dbname=$database", $username, $password);
    $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    if(isset($_POST["login"]))
    {
        if(empty($_POST["username"]) || empty($_POST["password"]))
        {
            $message = '<label>All fields are required</label>';
        }
        else
        {
            $query = "SELECT u.username,m.name, m.id 
                     FROM users u 
                     join mantaka m on u.mantaka_id = m.id
                    WHERE username = :username AND password = :password";
            $statement = $connect->prepare($query);
            $statement->execute(
                array(
                    'username'     =>     $_POST["username"],
                    'password'     =>     $_POST["password"]
                )
            );
            $count = $statement->rowCount();



            if($count > 0)
            {   //$result = $statement->fetchColumn(1);
                $row = $statement->fetch();
                $_SESSION["mantaka"] = $row[1];//$result;
                $_SESSION["uname"] = $_POST["username"];
                $result = $statement->fetchColumn(2);
                $_SESSION["mantakaId"] = $row[2];//$result;
                
                header("location:" . URLROOT . "/mantakaform/mantakaform");
            }
            else
            {
                $message = '<label>Wrong Data</label>';
            }
        }
    }
}
catch(PDOException $error)
{
    $message = $error->getMessage();
}
?>


<div class="container w3-padding-24" style="width:500px;">

    <form method="post">
        <label>Username</label>
        <input type="text" name="username" class="form-control" />
        <br />
        <label>Password</label>
        <input type="password" name="password" class="form-control" />
        <br />
        <input type="submit" name="login" class="btn btn-success" value="Login" />
    </form>
    <?php
    if(isset($message))
    {
        echo '<label class="text-danger">'.$message.'</label>';
    }
    ?>
</div>