<?php if(isset($_SESSION['uname'])){
    ?>

<div class="container w3-padding-32">
    <div class="w3-card-4 text-center">
         
        <h2 class="w3-center w3-margin-bottom" ><?php echo $_SESSION['mantaka'];?></h2>
        <input type="hidden" id="mantaka" class="form-control" value="<?php echo $_SESSION['mantaka'];?>">
        <input type="hidden" id="mantakaId" class="form-control" value="<?php echo $_SESSION['mantakaId'];?>">
        <div class="col">
        <label for="mnSijil" >من سجل</label>
        <input type="number" id="mnSijil" class="form-control" value="0">
        </div>
        <div class="col">
        <label for="elaSijil" >الى سجل</label>
        <input type="number" id="elaSijil" class="form-control"  value="999">
        </div>
        <input type="submit" value="عرض النتائج" class="btn btn-success w3-margin" style="width:50%" data-bind="click: filterResults">
    </div>

</div>
<div class="table-responsive">
<table class='table  table-bordered' id='individuals_table'>
        <tr class="bg-success w3-text-white">
			<th>ID</th>
            <th>Full Name</th>
			<th>Mother Name</th>
			<th>Birth Date</th>
			<th>Mazhab</th>
			<!-- <th>Sijil</th> -->
			<th>Contact</th>
			<th>Address</th>
			<th>Study</th>
			<th>Work</th>
			<th>Entimaa</th>
			<th>Movement</th>
			<th>Wasika</th>
        </tr><div>
        <tbody data-bind="foreach: individuals">
            <tr>
				<td><input data-bind='value: Id' disabled /></td>
                <td><input data-bind='value: firstName + " " + middleName +   " " + lastName' disabled /></td>
				<td><input data-bind='value: motherName' disabled/></td>
				<td><input type="date" data-bind='value: birthday' disabled/></td>
				<td><input data-bind='value: mazhab' disabled/></td>
				<!-- <input class="form-control" list="mazaheb" name="mazahebs" id="mazahebs" data-bind="value: mazhab">
					<datalist id="mazaheb">
					<select  data-bind="options:$root.mazhabs,optionsValue:'Id',optionsText:'title',optionsCaption:'اختر مذهب'" ></select>
					</datalist>
					<select  data-bind="options:$root.mazhabs,optionsValue:'Id',optionsText:'title',optionsCaption:'اختر مذهب'" ></select> -->
				
				<!-- <td><input type="number" data-bind='value: rakmSijil' disabled /></td> -->
				<td>
                     <table class="w3-border">
					 <td><input data-bind='value: contactName' />
					 <input type="text" data-bind='value: contactPhone' />
					 </td>
					 </table> 
                </td>
				<td>
					<table class="w3-border">
						<td>
							<select name="residencyType" id="residencyType" data-bind="options:$root.residencyTypes,optionsValue:'Id',optionsText:'title',optionsCaption:'اختر نوع الإقامة'" ></select>
							<select name="mantaka" id="mantaka" data-bind="options:$root.mantakas,optionsValue:'Id',optionsText:'title',optionsCaption:'اختر منطقة'" ></select>
						</td>
				
					</table>
				</td>
				<td>
					<table class="w3-border">
						<td>
						<select name="studyStatus" id="studyStatus"  data-bind="options:$root.studyStatuses,optionsValue:'Id',optionsText:'title',optionsCaption:'وضع الدراسة'" ></select>	
						<input data-bind='value: major' />
						<input data-bind='value: certificateType' />
						
					</td>
						
						
					</table>
				</td>
				<td>
					<table class="w3-border">
						<td>
						<select name="workType" id="workType"  data-bind="options:$root.workTypes,optionsValue:'Id',optionsText:'title',optionsCaption:'نوع العمل'" ></select>
						<br><input data-bind='value: workName' />	
					</td>
						
					</table>
				</td>
				<td>
					<table class=" w3-border">
						<td>
						<input class="form-control" list="entimaas" name="ent" id="ent"  data-bind="value: entimaaType">
						<datalist id="entimaas">
						<select data-bind="options:$root.entimaaTypes,optionsValue:'Id',optionsText:'title',optionsCaption:'اختر الانتماء السياسي'" ></select>
						</datalist>
						<!-- <select name="entimaa" id="entimaa"  data-bind="options:$root.entimaaTypes,optionsValue:'Id',optionsText:'title',optionsCaption:'اختر الانتماء السياسي'" ></select> -->
						</td>
						<td><input data-bind='value: entimaaSide' /></td>
					</table>
				</td>
				<td>
				<input class="form-control" list="movements" name="mov" id="mov"  data-bind="value: movementType">
				<datalist id="movements">
				<select data-bind="options:$root.movementTypes,optionsValue:'Id',optionsText:'title',optionsCaption:'اختر نوع النقل'" ></select>
				</datalist>
				<!-- <select name="movement" id="movement"  data-bind="options:$root.movementTypes,optionsValue:'Id',optionsText:'title',optionsCaption:'اختر نوع النقل'" ></select> -->
				</td>
				
				<td>
				<input class="form-control" list="wasikas" name="wask" id="wask"  data-bind="value: wasikaType">
				<datalist id="wasikas">
				<select   data-bind="options:$root.wasikaTypes,optionsValue:'Id',optionsText:'title',optionsCaption:'اختر وثيقة التعريف'" ></select> 
				</datalist>
				<!-- <select name="wasika" id="wasika"  data-bind="options:$root.wasikaTypes,optionsValue:'Id',optionsText:'title',optionsCaption:'اختر وثيقة التعريف'" ></select>  -->
				</td>
				<td><a href='#' data-bind='click: $root.editIndividual'>Edit</a></div> </td>
            </tr>
        </tbody>
    </table>
</div>
    <?php
   /*  $table_columns = ['الانتماء السياسي','جهة الانتماء' ,'وسيلة النقل' ,'وثيقة التعريف' ,'الإقامة' ,'رقم السجل' ,'المذهب' ,'اسم الأم وشهرتها','العائلة' ,'اسم الأب','الاسم الأول','رقم التعريف'];
    $table_properties = ["tableId" => "datatable_mform", "title" => '', 'title-size' => 'h3'];
    include(APPROOT . '/views/partials/_datatable_full_generic.php'); */
    ?>

<!-- 
<br><br>
<div class="row d-flex flex-row-reverse  ">
  <div class="col-sm-3 border w3-right-align w3-padding-24">
	<h4>المعلومات الشخصية</h4>
    
	<label for="firstname" >الاسم</label>
	<input type="text" id="firstname" class="form-control" data-bind="value:$root.newMantakaForm().firstName" >
	<label for="middlename">اسم الأب</label>
	<input type="text" id="middlename" class="form-control" data-bind="value:$root.newMantakaForm().middleName">
	<label for="lastname">العائلة</label>
	<input type="text" id="lastname" class="form-control" data-bind="value:$root.newMantakaForm().lastName">
	<label for="mothername">اسم الأم</label>
	<input type="text" id="mothername" class="form-control" data-bind="value:$root.newMantakaForm().motherName">
	<label for="birthday">تاريخ الولادة</label>
	<input type="date" id="birthday" class="form-control" data-bind="value:$root.newMantakaForm().birthday">
	<label for="mazhab">المذهب</label>
	<select name="mazhab" id="mazhab" class="form-control" data-bind="options:$root.mazhabs,value:$root.newMantakaForm().mazhabId,optionsValue:'Id',optionsText:'title',optionsCaption:'اختر مذهب'" ></select>
	<label for="contactName">اسم جهة الاتصال</label>
	<input type="text" id="contactName" class="form-control" data-bind="value:$root.newMantakaForm().contactName">
	<label for="contactPhone">رقم جهة الاتصال</label>
	<input type="number" id="contactPhone" class="form-control" data-bind="value:$root.newMantakaForm().contactPhone">
	
  </div>

  <div class="col-sm-3 border w3-right-align w3-padding-24" >
	<h4>العنوان</h4>
    <input type="checkbox" id="chk" value="disable" onclick=disableAddress(this)>
    <div id="address">
	<label for="residencyType">نوع الإقامة</label>
	<select name="residencyType" id="residencyType" class="form-control" data-bind="options:$root.residencyTypes,value:$root.newMantakaForm().residencyTypeId,optionsValue:'Id',optionsText:'title',optionsCaption:'اختر نوع الإقامة'" ></select>
	<label for="mantaka">المنطقة</label>
	<select name="mantaka" id="mantaka" class="form-control" data-bind="options:$root.mantakas,value:$root.newMantakaForm().mantakaId,optionsValue:'Id',optionsText:'title',optionsCaption:'اختر منطقة'" ></select>
	<label for="rakmsijil">رقم السجل</label>
	<input type="number" id="rakmsijil" class="form-control" data-bind="value:$root.newMantakaForm().rakmSijil">
	<label for="hay">الحي</label>
	<input type="text" id="hay" class="form-control" data-bind="value:$root.newMantakaForm().hay">
	<label for="street">الشارع</label>
	<input type="text" id="street" class="form-control" data-bind="value:$root.newMantakaForm().street">
	<label for="building">المبنى</label>
	<input type="text" id="building" class="form-control" data-bind="value:$root.newMantakaForm().building">
	<label for="floor">الطابق</label>
	<input type="number" id="floor" class="form-control" data-bind="value:$root.newMantakaForm().floor">
	<label for="phone">رقم الهاتف</label>
	<input type="number" id="phone" class="form-control" data-bind="value:$root.newMantakaForm().phone">
    </div>
  </div>
  <div class="col-sm-3 border w3-right-align w3-padding-24">
	<h4>الدراسة والعمل</h4>
      <input type="checkbox" id="chk" value="disable" onclick=disableProgress(this)>
      <div id="progress">
	<label for="studyStatus">حالة الدراسة</label>
	<select name="studyStatus" id="studyStatus" class="form-control" data-bind="options:$root.studyStatuses,value:$root.newMantakaForm().studyStatusId,optionsValue:'Id',optionsText:'title',optionsCaption:'وضع الدراسة'" ></select>
	<label for="certificateType">نوع الشهادة</label>
	<input type="text" id="certificateType" class="form-control" data-bind="value:$root.newMantakaForm().certificateTypeId()">
	<label for="major">الاختصاص</label>
	<input type="text" id="major" class="form-control" data-bind="value:$root.newMantakaForm().major">
	<label for="workType">نوع العمل</label>
	<select name="workType" id="workType" class="form-control" data-bind="options:$root.workTypes,value:$root.newMantakaForm().workTypeId,optionsValue:'Id',optionsText:'title',optionsCaption:'نوع العمل'" ></select>
	<label for="workName">اسم العمل</label>
	<input type="text" id="workName" class="form-control" data-bind="value:$root.newMantakaForm().workName">
      </div>
  </div>
  <div class="col-sm-3 border w3-right-align w3-padding-24">
	<h4>المعلومات الانتخابية</h4>
	<label for="entimaa">الانتماء السياسي</label>
	<select name="entimaa" id="entimaa" class="form-control" data-bind="options:$root.entimaaTypes,value:$root.newMantakaForm().entimaaId,optionsValue:'Id',optionsText:'title',optionsCaption:'اختر الانتماء السياسي'" ></select>
	<label for="entimaaName">جهة الانتماء السياسي</label>
	<input type="text" id="entimaaName" class="form-control" data-bind="value:$root.newMantakaForm().entimaaName">
	<label for="movement">وسيلة النقل</label>
	<select name="movement" id="movement" class="form-control" data-bind="options:$root.movementTypes,value:$root.newMantakaForm().movementId,optionsValue:'Id',optionsText:'title',optionsCaption:'اختر نوع النقل'" ></select>
	<label for="wasika">وثيقة التعريف</label>
	<select name="wasika" id="wasika" class="form-control" data-bind="options:$root.wasikaTypes,value:$root.newMantakaForm().wasikaId,optionsValue:'Id',optionsText:'title',optionsCaption:'اختر وثيقة التعريف'" ></select>

  </div>
</div>
<<div class=" w3-center">
	<input type="submit" value="إضافة الناخب أعلاه" class="btn btn-success w3-margin" style="width:50%" data-bind="click: addMantakaForm">
</div>
<?php
}
else
    header("location:" . URLROOT . "/login/login");
    ?>





<script>
	function disableAddress(chkb) {
		var div = document.getElementById('address');
		div.disabled = chkb.checked;
		var chl = div.children;
		for(var i=0; i< chl.length; i++)
		{
			chl[i].disabled = chkb.checked;
		}
	}
	function disableProgress(chkb) {
		var div = document.getElementById('progress');
		div.disabled = chkb.checked;
		var chl = div.children;
		for(var i=0; i< chl.length; i++)
		{
			chl[i].disabled = chkb.checked;
		}
	}
</script>


 -->