<?php

?>
<div class="container">
    <div class="row">
        <h1 class="display-3"><?php echo $data['title'] ?></h1>
    </div>
    <div class="row">
        <table class="table table-bordered bg-white">
            <tr>
                <th>
                    usage
                </th>
                <th>
                    code
                </th>
            </tr>
            <tr>
                <td>
                    main table
                </td>
                <td class="text-left">
                    <pre style="text-align: left;">
                        <code style="text-align: left;">
&lt;div class="col-8"&gt;
    &lt;div id="option_values_table_container" class="col-11"&gt;
        &lt;?php
        $table_columns = ['Username', 'Name', "Role"];
        $table_properties = ["tableId" =&gt; "datatable_users", "title" =&gt; 'Users', 'title-size' =&gt; 'h3'];
        include(APPROOT . '/views/partials/_datatable_full_generic.php');
        ?&gt;
    &lt;/div&gt;
&lt;/div&gt;
                        </code>
                    </pre>
                </td>
            </tr>
            <tr>
                <td>
                    main table open Item sidebar
                </td>
                <td class="text-left">
                    <pre style="text-align: left;">
                        <code style="text-align: left;">
&lt;div class="col-3 mt-5 ml-5"&gt;
    &lt;div class="card shadow" style="height: 100%;"&gt;
        &lt;div class="card-body"&gt;
            &lt;!--ko if : $root.currentUser().userName != '' --&gt;
            &lt;form id="editCurrentUserForm"&gt;
                &lt;h3 style="height: 3rem;" id="current_user_name" class="m-3" data-bind="text :$root.currentUser().name.charAt(0).toUpperCase() + $root.currentUser().name.slice(1)"&gt;&lt;/h3&gt;


                &lt;!--ko if : $root.currentUser().userName != '' --&gt;
                &lt;span style="font-size: 1rem;font-weight: bold;margin-top: 10rem"&gt;Username :&lt;/span&gt;
                &lt;input data-bind="textInput : $root.currentUser().userName" class="form-control mb-4"&gt;
                &lt;!-- /ko --&gt;


                &lt;!--ko if : $root.currentUser().userName != '' --&gt;
                &lt;span style="font-size: 1rem;font-weight: bold;"&gt;Name :&lt;/span&gt;
                &lt;input data-bind="textInput :  $root.currentUser().name" class="form-control mb-4"&gt;
                &lt;!-- /ko --&gt;


                &lt;!--ko if : $root.currentUser().userName != '' --&gt;
                &lt;span style="font-size: 1rem;font-weight: bold"&gt;Role :&lt;/span&gt;
                &lt;select class="form-control mb-4" name="category" id="current_user_role" data-bind="options : $root.userRoles,value:$root.currentUser().roleId,optionsValue : 'id',optionsText:'name',optionsCaption:'Choose Role'"&gt;&lt;/select&gt;
                &lt;!--                            &lt;span data-bind="text : $root.currentUser().order" class="mt-2"&gt;&lt;/span&gt;--&gt;
                &lt;!-- /ko --&gt;
                &lt;div class="row"&gt;
                    &lt;div class="col-6"&gt;
                        &lt;!--ko if : $root.currentUser().userName != '' --&gt;
                        &lt;label for="currentUserPassword" style="font-size: 1rem;font-weight: bold"&gt;Password :&lt;/label&gt;
                        &lt;div&gt;
                            &lt;label for="changeUserPasswordCheck" style="font-size: 1rem;font-weight: bold;"&gt;Reset :&lt;/label&gt;
                            &lt;input id="changeUserPasswordCheck" type="checkbox" data-bind="checked: $root.currentUser().changePass"&gt;
                        &lt;/div&gt;
                        &lt;input id="currentUserPassword" type="password" data-bind="textInput:$root.currentUser().password,enable:$root.currentUser().changePass()" class="passwordcheck form-control mb-4 " required&gt;
                        &lt;!-- /ko --&gt;
                    &lt;/div&gt;
                    &lt;div class="col-6"&gt;
                        &lt;!--ko if : $root.currentUser().userName != '' --&gt;
                        &lt;label for="deleteCurrentUser" style="font-size: 1rem;font-weight: bold"&gt;DELETE :&lt;/label&gt;
                        &lt;div&gt;
                            &lt;label for="deleteCurrentUserCheck" style="font-size: 1rem;font-weight: bold;"&gt;Enable :&lt;/label&gt;
                            &lt;input id="deleteCurrentUserCheck" type="checkbox" data-bind="checked: $root.currentUser().changePass"&gt;
                        &lt;/div&gt;
                        &lt;button type="button" class="btn btn-danger" id="submitEditUser" data-bind="click:$root.deleteCurrentUser,enable:$root.currentUser().changePass()"&gt;Delete&lt;/button&gt;
                        &lt;!-- /ko --&gt;
                    &lt;/div&gt;
                &lt;/div&gt;
                &lt;div class="row justify-content-around"&gt;
                    &lt;div class="col-4 d-flex justify-content-start"&gt;
                        &lt;button type="button" class="btn btn-secondary" id="clearEditUser" data-bind="click:$root.clearCurrentUserEdits"&gt;Clear&lt;/button&gt;
                    &lt;/div&gt;
                    &lt;div class="col-4"&gt;&lt;/div&gt;
                    &lt;div class="col-4 d-flex justify-content-end "&gt;
                        &lt;button type="button" class="btn btn-success" id="submitEditUser" data-bind="click:$root.submitCurrentUserEdits"&gt;Submit&lt;/button&gt;
                    &lt;/div&gt;

                &lt;/div&gt;
            &lt;/form&gt;
            &lt;!-- /ko --&gt;
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/div&gt;
                        </code>
                    </pre>
                </td>
            </tr>
            <tr>
                <td>
                    Add Item modal
                </td>
                <td class="text-left">
                    <pre style="text-align: left;">
                        <code style="text-align: left;">
&lt;!--Add User Modal--&gt;
&lt;div id="new_user_modal" class="modal show" style="z-index: 1110;"&gt;
    &lt;div class="modal-dialog" role="document"&gt;
        &lt;div class="modal-content"&gt;
            &lt;div class="modal-header"&gt;&lt;h5 class="modal-title" id="new_user_modal_label"&gt;New User&lt;/h5&gt;
                &lt;button type="button" class="close" data-dismiss="modal"&gt;
                    &lt;span&gt;&times;&lt;/span&gt;
                &lt;/button&gt;
            &lt;/div&gt;
            &lt;div class="modal-body"&gt;
                &lt;form id="addUserForm" autocomplete="off"&gt;
                    &lt;div class="form-group"&gt;
                        &lt;label for="new_user_username"&gt;User Name&lt;/label&gt;
                        &lt;input id="new_user_username" autocomplete="new-password" name="username" data-bind="textInput :  $root.newUserUsername,attr : {'placeholder' : 'UserName'}" class="form-control" type="text" required/&gt;
                        &lt;label for="new_user_name"&gt;Name&lt;/label&gt;
                        &lt;input id="new_user_name" autocomplete="new-password" name="name" data-bind="textInput :  $root.newUserName,attr : {'placeholder' : 'Name'}" class="form-control" type="text" required/&gt;
                        &lt;label for="new_user_password"&gt;Password&lt;/label&gt;
                        &lt;input id="new_user_password" autocomplete="new-password" name="password" pattern=".{0}|.{8,}" data-bind="textInput :  $root.newUserPassword,attr : {'placeholder' : 'Password should be 8 or more characters'}" class="form-control passwordcheck" type="password" required/&gt;
                        &lt;label for="new_user_role"&gt;Role&lt;/label&gt;
                        &lt;select class="form-control" name="category" id="new_user_role" data-bind="options : $root.userRoles,value:$root.newUserRoleId,optionsValue : 'id',optionsText:'name',optionsCaption:'Choose Role'" required&gt;&lt;/select&gt;
                    &lt;/div&gt;
                    &lt;div class="modal-footer"&gt;
                        &lt;button type="button" class="btn btn-secondary mr-auto" data-bind="click:$root.clearNewUserModal"&gt;Clear&lt;/button&gt;
                        &lt;button type="button" class="btn btn-secondary" data-dismiss="modal"&gt;Close&lt;/button&gt;
                        &lt;button id="save_new_user_btn" type="button" data-bind="click:$root.addUser" class="btn btn-primary"&gt;Save changes&lt;/button&gt;
                    &lt;/div&gt;
                &lt;/form&gt;
            &lt;/div&gt;&lt;!-- /.modal-content --&gt;
        &lt;/div&gt;&lt;!-- /.modal-dialog --&gt;
    &lt;/div&gt;&lt;!-- /.modal --&gt;
&lt;/div&gt;
                        </code>
                    </pre>
                </td>
            </tr>
            <tr>
                <td>FULL PAGE SHAPE</td>
                <td class="text-left">
                    <pre>
                        <code>
&lt;div class="container-fluid" style="margin-bottom: 5rem"&gt;
    &lt;div class="row"&gt;
    &lt;/div&gt;
&lt;/div&gt;  
                        </code>
                    </pre>
                </td>
            </tr>
        </table>
    </div>