<?php
//Load Config
require_once 'config/config.php';

//Load Helpers
require_once 'helpers/session_helper.php';
require_once 'helpers/url_helper.php';

// Load Libraries the old way
// Load the TCPDF library since it is in another folder
//require_once 'helpers/TCPDF/tcpdf.php';

//Autoload Core Libraries
//libraries that are in another folder or name unlike folder need to be handled alone
//it is important to note that the files in the folders
//inside of libraries folder, need to be same name as
//the folders
spl_autoload_register(function ($classname) {
    if ($classname != 'TCPDF'){
    require_once 'libraries/' . $classname . '.php';
    }

});