

let mform_view_model;
mform_view_model = new MantakaFormViewModel();

function MantakaFormViewModel() {
    const self = this;

    self.currentRow = ko.observable();
    self.currentMantakaForm = ko.observable(new MantakaForm());
    self.newMantakaForm = ko.observable(new MantakaForm());
    self.individuals = ko.observableArray([]);
    self.mform = ko.observableArray([]);
    self.mazhabs = ko.observableArray([]);
    self.mantakas = ko.observableArray([]);
    self.residencyTypes = ko.observableArray([]);
    self.studyStatuses = ko.observableArray([]);
    self.workTypes = ko.observableArray([]);
    self.entimaaTypes = ko.observableArray([]);
    self.movementTypes = ko.observableArray([]);
    self.wasikaTypes = ko.observableArray([]);

    self.getAllIndividuals = function () {
        let route = ['mantakaform', 'requests', 'getIndividuals'];
        fetchDataJson(route, {}, function (individuals) {
            self.individuals(individuals);
            console.log(self.individuals());
            
        });
    };
    self.getAllIndividuals();
    
    self.editIndividual = function(individual) {
        console.log(individual);
        console.log(individual.mazhab);
        console.log(individual.movementType);
        let route = ['mantakaform', 'requests', 'updateRow'];
        postData(route, individual, function (result) {
            if (result == '1') {
                toastr.success('تم التعديل');
                self.individuals.remove(individual);
            }
            else {
                toastr.warning('فشل عملية التعديل');
            }
            //$('#datatable_mantakas').DataTable().ajax.reload();
            
        });
        
    };
    self.getMantakas = function () {
        let route = ['mantakaform', 'requests', 'getMantakas'];
        fetchDataJson(route, {}, function (mantakas) {
            self.mantakas(mantakas);
            console.log(self.mantakas);
        });
    };
    self.getMantakas();

    self.getMazhabTypes = function () {
        let route = ['mantakaform', 'requests', 'getMazhabTypes'];
        fetchDataJson(route, {}, function (mazhabTypes) {
            self.mazhabs(mazhabTypes);
            console.log(self.mazhabs);
        });
    };
    self.getMazhabTypes();
    self.getResidencyTypes = function () {
        let route = ['mantakaform', 'requests', 'getResidencyTypes'];
        fetchDataJson(route, {}, function (residencyTypes) {
            self.residencyTypes(residencyTypes);
            console.log(self.residencyTypes);
        });
    };
    self.getResidencyTypes();
    self.getStudyStatuses = function () {
        let route = ['mantakaform', 'requests', 'getStudyStatuses'];
        fetchDataJson(route, {}, function (studyStatuses) {
            self.studyStatuses(studyStatuses);
            console.log(self.studyStatuses);
        });
    };
    self.getStudyStatuses();
    self.getWorkTypes = function () {
        let route = ['mantakaform', 'requests', 'getWorkStatuses'];
        fetchDataJson(route, {}, function (workTypes) {
            self.workTypes(workTypes);
            console.log(self.workTypes);
        });
    };
    self.getWorkTypes();
    self.getEntimaaTypes = function () {
        let route = ['mantakaform', 'requests', 'getEntimaaTypes'];
        fetchDataJson(route, {}, function (entimaaTypes) {
            self.entimaaTypes(entimaaTypes);
            console.log(self.entimaaTypes);
        });
    };
    self.getEntimaaTypes();
    self.getMovementTypes = function () {
        let route = ['mantakaform', 'requests', 'getMovementTypes'];
        fetchDataJson(route, {}, function (movementTypes) {
            self.movementTypes(movementTypes);
            console.log(self.movementTypes);
        });
    };
    self.getMovementTypes();
    self.getWasikaTypes = function () {
        let route = ['mantakaform', 'requests', 'getWasikaTypes'];
        fetchDataJson(route, {}, function (wasikaTypes) {
            self.wasikaTypes(wasikaTypes);
            console.log(self.wasikaTypes);
        });
    };
    self.getWasikaTypes();

    self.addMantakaForm = function () {
        
        
        let route = ['mantakaform', 'requests', 'addMantakaForm'];
        let mantaka = {};

        //PERSONAL INFO
        mantaka.firstName = self.newMantakaForm().firstName();
        mantaka.middleName = self.newMantakaForm().middleName();
        mantaka.lastName = self.newMantakaForm().lastName();
        mantaka.motherName = self.newMantakaForm().motherName();
        mantaka.birthday = self.newMantakaForm().birthday();
        mantaka.mazhabId = self.newMantakaForm().mazhabId();
        mantaka.rakmSijil = self.newMantakaForm().rakmSijil();
        mantaka.contactName = self.newMantakaForm().contactName();
        mantaka.contactPhone = self.newMantakaForm().contactPhone();
        //ADDRESS INFO
        mantaka.mantakaId = self.newMantakaForm().mantakaId();
        mantaka.hay = self.newMantakaForm().hay();
        mantaka.street = self.newMantakaForm().street();
        mantaka.building = self.newMantakaForm().building();
        mantaka.floor = self.newMantakaForm().floor();
        mantaka.phone = self.newMantakaForm().phone();
        mantaka.residencyTypeId = self.newMantakaForm().residencyTypeId();
        //PROGRESS INFO
        mantaka.major = self.newMantakaForm().major();
        mantaka.certificateTypeId = self.newMantakaForm().certificateTypeId();
        mantaka.studyStatusId = self.newMantakaForm().studyStatusId();
        mantaka.workName = self.newMantakaForm().workName();
        mantaka.workTypeId = self.newMantakaForm().workTypeId();
        //ELECTIONS INFO
        mantaka.entimaaId = self.newMantakaForm().entimaaId();
        mantaka.entimaaName = self.newMantakaForm().entimaaName();
        mantaka.movementId = self.newMantakaForm().movementId();
        mantaka.wasikaId = self.newMantakaForm().wasikaId();
        console.log(mantaka);
        postData(route, mantaka, function (result) {
            console.log(result);
            if (result) {
                toastr.success('تمت الإضافة بنجاح');
                //self.clearnewMantakaFormModal();
                //$('#datatable_mantakas').DataTable().ajax.reload();

            }
            else {
                toastr.warning('فشل في عملية الإضافة');
            }
        });
       // $('#datatable_mantakas').DataTable().ajax.reload();
        //$('#add_mantaka_modal').modal('hide');
        
    };

    
    self.editRow = function(data){
        console.log(data);
        let mantaka = {};
        let firstName = document.getElementById(data + 'firstName').value;
        let middleName = document.getElementById(data + 'middleName').value;
        let lastName = document.getElementById(data + 'lastName').value;
        let motherName = document.getElementById(data + 'motherName').value;
        let mazhab = document.getElementById(data + 'mazhab').value;
        let rakmSijil = document.getElementById(data + 'rakmSijil').value;
        let residencyType =  document.getElementById(data + 'residencyType').value;
        let wasikaType = document.getElementById(data + 'wasikaType').value;
        let movementType = document.getElementById(data + 'movementType').value;
        let entimaaSide = document.getElementById(data + 'entimaaSide').value;
        let entimaaType = document.getElementById(data + 'entimaaType').value;
       
       
        mantaka.Id = data;
        mantaka.firstName = firstName;
        mantaka.middleName = middleName;
        mantaka.lastName = lastName;
        mantaka.motherName = motherName;
        mantaka.mazhab = mazhab;
        mantaka.rakmSijil = rakmSijil;
        mantaka.residencyType = residencyType;
        mantaka.wasikaType = wasikaType;
        mantaka.movementType = movementType;
        mantaka.entimaaSide = entimaaSide; 
        mantaka.entimaaType = entimaaType;
    
        console.log(mantaka);


        let route = ['mantakaform', 'requests', 'updateRow'];
          
            postData(route, mantaka, function (result) {
                if (result == '1') {
                    toastr.success('تم التعديل');
                    
                }
                else {
                    toastr.warning('فشل عملية التعديل');
                }
                $('#datatable_mantakas').DataTable().ajax.reload();
                
            });
    };
    

}

function MantakaForm(mantaka) {

    const self = this;

    //PERSONAL INFO     
    self.id = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.id);
    self.firstName = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.firstName);
    self.middleName = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.middleName);
    self.lastName = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.lastName);
    self.motherName = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.motherName);
    self.birthday = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.birthday);
    self.mazhabId = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.mazhabId);
    self.rakmSijil = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.rakmSijil);
    self.contactName = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.contactName);
    self.contactPhone = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.contactPhone);
    //ADDRESS INFO
    self.mantakaId = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.mantakaId);
    self.hay = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.hay);
    self.street = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.street);
    self.building = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.building);
    self.floor = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.floor);
    self.phone = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.phone);
    self.residencyTypeId = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.residencyTypeId);
    //PROGRESS INFO
    self.major = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.major);
    self.certificateTypeId = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.certificateTypeId);
    self.studyStatusId = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.studyStatusId);
    self.workName = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.workName);
    self.workTypeId = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.workTypeId);
    //ELECTIONS INFO
    self.entimaaId = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.entimaaId);
    self.entimaaName = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.entimaaName);
    self.movementId = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.movementId);
    self.wasikaId = mantaka == undefined ? ko.observable('') : ko.observable(mantaka.wasikaId);

    
}


self.filterResults = function (){
    var mn = parseInt(document.getElementById('mnSijil').value);
    var ela = parseInt(document.getElementById('elaSijil').value);
    var mantakaId = document.getElementById('mantakaId').value;
    
    if (mn > ela) {
        alert("error");
    }
    else{
        let table = $('#datatable_mform').DataTable();
        table.destroy();
        var MantakaFormsTableId = 'datatable_mform';
        var MantakaFormsButtonFunc = 'alert("Hi");';
        var MantakaFormsDomParams = 'lfrtip';
        var MantakaFormsContentName = 'MantakaForm';
        var MantakaFormsDatatableAjaxRoute = '/mantakaform/requests/getAllIndividuals/' + mn + '/' + ela + '/' + mantakaId + '/datatablesEncode';
        var MantakaFormsColumns = [
            {'data': ['entimaaType', 'new String(\'<select class="form-control w3-tiny w3-left" id="\' + row.Id + \'entimaaType" value="\' + row.entimaaType + \'"><option value="1">حركي(ة)</option> <option value="2">مؤيد(ة)</option> <option value="3">مستقل(ة)</option><option value="4">مناهض(ة)</option> <option value="5">حزبي(ة)</option> <option value="6">مؤيد(ة) لحزب</option></select>\')']},
            {'data': ['entimaaSide' , 'new String(\'<input type="text" id="\' + row.Id + \'entimaaSide" value=" \' + row.entimaaSide + \'" class="w3-small col-md-3"> \')']},
            {'data': ['movementType' , 'new String(\'<select class="form-control w3-tiny " id="\' + row.Id + \'movementType" value="\' + row.movementType + \'"><option value="1">شخصي</option><option value="2">بنزين</option><option value="3">نقل عام</option></select>\')']},
            {'data': ['wasikaType' , 'new String(\'<select class="form-control w3-tiny " id="\' + row.Id + \'wasikaType" value="\' + row.wasikaType + \'"><option value="1">بطاقة هوية</option><option value="2">جواز سفر</option><option value="3">لا يوجد</option></select>\')']},
            {'data': ['residencyType' , 'new String(\'<select class="form-control w3-tiny w3-left " id="\' + row.Id + \'residencyType" value="\' + row.residencyType + \'"><option value="1">داخل البلدة</option> <option value="2">خارج البلدة</option> <option value="3">مغترب</option></select>\')']},
            {'data': ['rakmSijil' , 'new String(\'<input type="text" id="\' + row.Id + \'rakmSijil" value=" \' + row.rakmSijil + \'" class="w3-tiny col-md-2" > \')']},
            {'data': ['mazhab' , 'new String(\'<select class="form-control w3-tiny w3-left" id="\' + row.Id + \'mazhab" value="\' + row.mazhab + \'"><option value="1">سنّي</option> <option value="2">شيعي</option> <option value="9">درزي</option> <option value="11">مسيحي</option> </select>\')']},
            {'data': ['motherName' , 'new String(\'<input type="text" id="\' + row.Id + \'motherName" value=" \' + row.motherName + \'" class="w3-tiny col-md-3"> \')']},
            {'data': ['lastName' , 'new String(\'<input type="text" id="\' + row.Id + \'lastName" value=" \' + row.lastName + \'" class="w3-tiny col-md-3"> \')']},
            {'data': ['middleName' , 'new String(\'<input type="text" id="\' + row.Id + \'middleName" value=" \' + row.middleName + \'" class="w3-tiny col-md-2"> \')']},
            {'data': ['firstName' , 'new String(\'<input type="text" id="\' + row.Id + \'firstName" value=" \' + row.firstName + \'" class="w3-tiny col-md-2"> \')']},
            {'data': ['Id' , 'new String(\'<button  onclick="mform_view_model.editRow(\' + data + \')" class="btn btn-success btn-sm w3-tiny"> تعديل <span class="fa fa-share-square"> </span></button>\')']}

        ];
        configureDatatable(MantakaFormsTableId, MantakaFormsButtonFunc,{}, MantakaFormsDomParams, MantakaFormsContentName, MantakaFormsDatatableAjaxRoute, MantakaFormsColumns);

    }
};




ko.applyBindings(mform_view_model);

$(document).ready(function () {
    let table = $('#datatable_mform').DataTable();

    // make all table row show pointers on hover
    $.each($('#datatable_mform tbody tr'), function (index, tr) {
        tr.style.cursor = 'pointer';
    });

    $('#datatable_mform tbody').on('click', 'tr', function () {

        mform_view_model.currentRow(this);
        this.style.cursor = 'pointer';
        let data = ko.toJS(table.row(this).data());
        mform_view_model.newMantakaForm(new MantakaForm(data));
        console.log(data);
        //$('#edit_FixedAsset_modal').modal('show');
        //console.log(fixedasset_view_model.groups());

    });

    //this allows for a custom message in case the user enters an invalid password

});


