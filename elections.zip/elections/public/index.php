<?php
require_once '../app/bootstrap.php';
//Init Core library

$init = new Core();