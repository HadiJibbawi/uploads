
const fixedassetId = document.querySelector('#fixedassetId').value;
const asset_view_model = new AssetViewModel();
const statusIds = {
    0 : 'Inactive',
    1 : 'Active'
};


function AssetViewModel() {

    const self = this;


    self.originalAsset = ko.observable(new Asset());
    self.currentAsset = ko.observable(new Asset());
    self.newAssetCategory = ko.observable(new AssetCategory());
    self.faGroups = ko.observableArray([]);
    self.subCategories = ko.observableArray([]);
    self.accounts = ko.observableArray([]);
    self.categories = ko.observableArray([]);
    self.newGroup = ko.observable();
    self.depreciationAmount = ko.observable(0);
    self.getAllsubCategories = function () {
        let route = ['fixedassets', 'requests', 'getAllsubCategories'];
        fetchDataJson(route, {}, function (categories) {
            self.subCategories(categories);
        });
    };

    self.getAllgroups = function () {
        let route = ['fixedassets', 'requests', 'getAllgroups'];
        fetchDataJson(route, {}, function (groups) {
            self.faGroups(groups);

        });
    };

    self.getAllaccounts = function () {
        let route = ['fixedassets', 'requests', 'getAllaccounts'];
        fetchDataJson(route, {}, function (accounts) {
            self.accounts(accounts);
        });
    };
    self.getAllcategories = function () {
        let route = ['fixedassets', 'requests', 'getAllcategories'];
        fetchDataJson(route, {}, function (categories) {
            self.categories(categories);
            console.log(self.categories);

        });
    };
    self.getAsset = function () {
        let route = ['fixedassets', 'requests', 'getAsset'];
        fetchDataJson(route, { 'assetId': fixedassetId }, function (data) {
            self.originalAsset(new Asset(data));
            self.currentAsset(new Asset(data));
            // console.log("Asset ID:" + fixedassetId);
            //console.log(ko.toJS(self.originalAsset()));
            //console.log(ko.toJS(self.currentAsset()));

        });
    };

    self.getAllsubCategories();
    self.getAllgroups();
    self.getAsset();
    self.getAllaccounts();
    self.getAllcategories();

    self.resetCurrentAsset = function () {
        let data = ko.toJS(self.originalAsset());
        asset_view_model.currentAsset(new Asset(data));
    };

    self.submitEditAsset = function () {

            let route = ['fixedassets', 'requests', 'updateFixedAsset'];
            let asset = {};
            const originalFAsset = ko.toJS(self.originalAsset());
            const currentFAsset = ko.toJS(self.currentAsset());
            //console.log(originalFAsset);
            //console.log(currentFAsset);
            for (const prop in originalFAsset) {
              
                if (originalFAsset[prop] != currentFAsset[prop]) {
                    if (prop != 'faGroup' || prop !='subCategory' || (prop = 'faGroup' && currentFAsset['faGroup'] ) || (prop = 'subCategory' && currentFAsset['v'] )){
                        asset[prop] = currentFAsset[prop];
                    }    
                }    
            
            }

            if ($.isEmptyObject(asset)) {
                alert('No changes have been made');
                return;
            }
            asset['id'] = originalFAsset.id;
          
            postData(route, asset, function (result) {
                if (result == '1') {
                    toastr.success('Asset Edited Successfully');
                    location.reload();
                }
                else {
                    toastr.warning('Asset Edit Failed');
                }
            });
    };

    self.transferAssetAccount = function(){
        let route = ['fixedassets','requests','transferAssetAccount'];
        let asset = {};
        const originalAsset = ko.toJS(self.originalAsset());
        const currentAsset = ko.toJS(self.currentAsset());
        
        if (originalAsset["accountId"] != currentAsset["accountId"] && currentAsset["accountId"]) {
                asset["accountId"] = currentAsset["accountId"];
               // console.log(asset["accountId"]);
            }
            //console.log(ko.toJS(self.originalAsset()));
            //console.log(ko.toJS(self.currentAsset()));
            if ($.isEmptyObject(asset)) {
            alert('No changes have been made');
            return;
        }
        asset['assetId'] = originalAsset.id;
        postData(route, asset, function (result) {
            if (result == '1') {
                toastr.success('Asset Transfered Successfully');
            }
            else {
                toastr.warning('Asset Transfered Failed');
            }
        });
     
    };

    self.manualAssetDepreciation = function(){
        let route = ['fixedassets','requests','manualAssetDepreciation'];
        let asset = {};
        const originalAsset = ko.toJS(self.originalAsset());
        const currentAsset = ko.toJS(self.currentAsset());
        console.log(originalAsset);
        console.log(currentAsset);

            asset["originalCost"] = parseInt(self.originalAsset().cost());
            asset["depreciationAmount"] = self.depreciationAmount();
            asset["currentCost"] = asset["originalCost"] - asset["depreciationAmount"];


            if(parseInt(asset["depreciationAmount"]) > parseInt(originalAsset["cost"]) || parseInt(asset["depreciationAmount"]) <= 0 ){
                alert('Kindly Enter Valid Amount');
                return;
            }
            if ($.isEmptyObject(asset)) {
            alert('No changes have been made');
               // location.reload();
            return;
        }
        asset['assetId'] = originalAsset.id;
        postData(route, asset, function (result) {
            if (result == '1') {
                toastr.success('Asset Depreciated Successfully');
               // location.reload();
            }
            else {
                toastr.warning('Asset Depreciated Failed');
                //location.reload();
            }
        });
     
    };

    self.addAssetCategory = function(){
        let route = ['fixedassets', 'requests', 'addAssetCategory'];
        let assetcategory = {};

        assetcategory.title = self.newAssetCategory().title();
        assetcategory.categoryId = self.newAssetCategory().categoryId();

        console.log(assetcategory);
        postData(route, assetcategory, function (result) {
            console.log(result);
            if (result) {
                toastr.success('Fixed Asset Category Added Successfully');
            }
            else {
                toastr.warning('Fixed Asset Category Addition Failed');
            }
        });


    };
// UAT //
    self.addAssetGroup = function(){
        let route = ['fixedassets', 'requests', 'addAssetGroup'];
        let assetgroup = {};

        assetgroup.group = self.newGroup();


        console.log(assetgroup);
        postData(route, assetgroup, function (result) {
            console.log(result);
            if (result) {
                toastr.success('Fixed Asset Group Added Successfully');
            }
            else {
                toastr.warning('Fixed Asset Group Addition Failed');
            }
        });


    };
// End UAT //

}


function Asset(fixedasset) {

    const self = this;
    self.id = fixedasset == undefined ? ko.observable('') : ko.observable(fixedasset.id);
    self.title = fixedasset == undefined ? ko.observable('') : ko.observable(fixedasset.title);
    self.cost = fixedasset == undefined ? ko.observable('') : ko.observable(fixedasset.cost);
    self.status = fixedasset == undefined ? ko.observable('') : ko.observable(fixedasset.status);
    self.acquisitionDate = fixedasset == undefined ? ko.observable('') : ko.observable(fixedasset.acquisitionDate);
    self.description = fixedasset == undefined ? ko.observable('') : ko.observable(fixedasset.description);
    self.faLocation = fixedasset == undefined ? ko.observable('') : ko.observable(fixedasset.faLocation);
    self.subCategory = fixedasset == undefined ? ko.observable('') : ko.observable(fixedasset.subCategory);
    self.faGroup = fixedasset == undefined ? ko.observable('') : ko.observable(fixedasset.faGroup);
    self.depreciatesOn = fixedasset == undefined ? ko.observable('') : ko.observable(fixedasset.depreciatesOn);
    self.accountId = fixedasset == undefined ? ko.observable('') : ko.observable(fixedasset.accountId);
    self.accountNumber = fixedasset == undefined ? ko.observable('') : ko.observable(fixedasset.accountNumber);

    self.enableDelete = ko.observable(false);
    self.displayName = self.title;

}

function AssetCategory(subCategory) {

    const self = this;
    self.id = subCategory == undefined ? ko.observable('') : ko.observable(subCategory.id);
    self.title = subCategory == undefined ? ko.observable('') : ko.observable(subCategory.title);
    self.categoryId = subCategory == undefined ? ko.observable('') : ko.observable(subCategory.categoryId);

}

ko.applyBindings(asset_view_model);



const transfersTableId = 'datatable_transfers';
const transfersButtonFunc = 'alert("hello");';
const transfersDomParams = 'lfBrtip';
const transfersContentName = 'FixedAsset';
const transfersDatatableAjaxRoute = '/fixedassets/requests/getAllAssetTransfers/' + fixedassetId +'/datatablesEncode';
const transfersColumns = [
    {'data': ['accountNumber' , 'false']},
    {'data': ['startDate' , 'false']},
    {'data': ['endDate' , 'false']}
];

configureDatatable(transfersTableId, transfersButtonFunc,{}, transfersDomParams, transfersContentName, transfersDatatableAjaxRoute, transfersColumns);
$(document).ready(function () {
    
    $.each($('#datatable_transfers tbody tr'), function (index, tr) {
        tr.style.cursor = 'pointer';
    });



}); 

const fixedassetsTableId = 'datatable_depreciations';
const fixedassetsButtonFunc = 'alert("hello");';
const fixedassetsDomParams = 'lfBrtip';
const fixedassetsContentName = 'FixedAsset';
const fixedassetsDatatableAjaxRoute = '/fixedassets/requests/getAllAssetDepreciations/' + fixedassetId +'/datatablesEncode';
const fixedassetsColumns = [
    {'data': ['assetId' , 'false']},
    {'data': ['currentAmount' , 'false']},
    {'data': ['depreciationAmount' , 'false']},
    {'data': ['depreciationDate' , 'false']}
];

configureDatatable(fixedassetsTableId, fixedassetsButtonFunc,{}, fixedassetsDomParams, fixedassetsContentName, fixedassetsDatatableAjaxRoute, fixedassetsColumns);
$(document).ready(function () {
    
    $.each($('#datatable_transfers tbody tr'), function (index, tr) {
        tr.style.cursor = 'pointer';
    });



}); 