<?php

class FixedAssets extends Controller
{
    private $fixedassetModel;

    public function __construct()
    {
        $this->fixedassetModel = $this->model('FixedAsset');
    }

    //this function is here is the index root function
    public function index()
    {
        $data = ['title' => 'Baydoun Design', 'description' => 'Please login if you\'re an admin or else, please register'];
        $this->view('pages/index', $data);

    }

    public function fixedassets()
    {
        $data = ['title' => 'Fixed Assets', 'description' => 'Page for Fixed Assets Management'];
        $template = [];
        $template['page_script'] = 'fixedassets';
        $this->view('admin/fixedassets', $data, $template);
    }

    public function fixedasset($id = null)
    {
        if ($id == null) {
            die('invalid parameters');
        }
        else {
            $fixedasset = $this->fixedassetModel->getFixedAsset($id);
            $data = ['fixedassetId' => $id, 'title' => ucfirst($fixedasset->title), 'description' => 'Page for Asset Details', 'fixedasset' => $fixedasset];
            $template = [];
            $template['page_script'] = 'fixedasset';
            $this->view('admin/fixedasset', $data, $template);
            die($id);
        }
    }

    private function addFixedAsset($fixedasset)
    {

        return $this->fixedassetModel->addFixedAsset($fixedasset);
    }
    private function addAssetCategory($assetcategory){
        return $this->fixedassetModel->addAssetCategory($assetcategory);
    }
    private function addAssetGroup($assetgroup){
        return $this->fixedassetModel->addAssetGroup($assetgroup);
    }
    private function transferAssetAccount($fixedasset)
    {
        return $this->fixedassetModel->transferAssetAccount($fixedasset);
    }

    private function updateFixedAsset($fixedasset)
    {
        foreach ($fixedasset as $key => $item) {
            $newKey = $this->camelCaseToUnderscore($key);
            if ($newKey == $key) {
                continue;
            }
            $fixedasset[$newKey] = $item;
            unset($fixedasset[$key]);
        }

        echo $this->fixedassetModel->updateFixedAsset($fixedasset);
    }


    private function deleteFixedAsset($id)
    {
        return $this->fixedassetModel->deleteFixedAsset($id['id']);
    }

    private function manualAssetDepreciation($fixedasset)
    {
        return $this->fixedassetModel->manualAssetDepreciation($fixedasset);
    }

    public function requests($request)
    {
        switch ($request) {
            case 'getAllFixedAssets':
                if (isset(func_get_args()[1])) {

                    if (func_get_args()[1] == 'datatablesEncode') {
                        echo $this->datatables_encode($this->fixedassetModel->getAllFixedAssets());
                    }
                    else {
                        echo $this->encode_json($this->fixedassetModel->getAllFixedAssets());
                    }
                }
                else {
                    echo $this->encode_json($this->fixedassetModel->getAllFixedAssets());
                }
                break;
            case 'getAllsubCategories':
                echo self::encode_json($this->fixedassetModel->getAllsubCategories());
                break;
            case 'getAllgroups':
                echo self::encode_json($this->fixedassetModel->getAllgroups());
                break;
            case 'getAllaccounts':
                echo self::encode_json($this->fixedassetModel->getAllaccounts());
                break;
            case 'getAllcategories':
                echo self::encode_json($this->fixedassetModel->getAllcategories());
                break;
            case 'addFixedAsset':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->addFixedAsset($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'addAssetCategory':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->addAssetCategory($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'addAssetGroup':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->addAssetGroup($_POST);
                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'updateFixedAsset':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $this->updateFixedAsset($_POST);
                }
                else {
                    $this->fixedassets();
                }
                break;
            case 'transferAssetAccount':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->transferAssetAccount($_POST);
                }
                else {
                    $this->fixedassets();
                }
                break;
            case 'manualAssetDepreciation':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->manualAssetDepreciation($_POST);
                }
                else {
                    $this->fixedassets();
                }
                break;
            case 'deleteFixedAsset':
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo $this->deleteFixedAsset($_POST);

                }
                else {
                    echo 'invalid request data';
                }
                break;
            case 'getAsset':
                if (isset($_GET)) {
                    echo $this::encode_json($this->fixedassetModel->getFixedAsset($_GET['assetId']));
                }
                else {
                    echo 'invalid parameters';
                }
                break;
            case 'getAllAssetTransfers':
                if (func_get_args()[1] == null) {
                    echo 'invalid parameters';
                    break;
                }
                else {
                    $id = func_get_args()[1];
                    if (isset(func_get_args()[2])) {
                        if (func_get_args()[2] == 'datatablesEncode') {
                            echo $this->datatables_encode($this->fixedassetModel->getAllAssetTransfers($id));
                        }
                        else {
                            echo $this->encode_json($this->fixedassetModel->getAllAssetTransfers($id));
                        }
                    }
                    else{
                        echo $this::encode_json($this->fixedassetModel->getAllAssetTransfers($id));
                    }
                    break;
                }
            case 'getAllAssetDepreciations':
                if (func_get_args()[1] == null) {
                    echo 'invalid parameters';
                    break;
                }
                else {
                    $id = func_get_args()[1];
                    if (isset(func_get_args()[2])) {
                        if (func_get_args()[2] == 'datatablesEncode') {
                            echo $this->datatables_encode($this->fixedassetModel->getAllAssetDepreciations($id));
                        }
                        else {
                            echo $this->encode_json($this->fixedassetModel->getAllAssetDepreciations($id));
                        }
                    }
                    else{
                        echo $this->encode_json($this->fixedassetModel->getAllAssetDepreciations($id));
                    }
                    break;
                }

            case 'getAssetAccount':
                if (isset($_GET)) {
                    echo $this::encode_json($this->fixedassetModel->getAssetAccount($_GET['assetId']));
                }
                else {
                    echo 'invalid parameters';
                }
                break;
            default:
                echo "invalid request";
                break;
        }
    }
}

?>