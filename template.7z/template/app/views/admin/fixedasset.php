<?php
/**
 * Created by PhpStorm.
 * User: Jaafar1018
 * Date: 29/04/20
 * Time: 2:40 PM
 */
?>
<?php  $fixedasset = $data['fixedasset'];  

    
?>

<div class="container-fluid" style="margin: 5rem 0">
    <div class="card">
        <div class="card-body">
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" id="fixedassetTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="assetinfo-tab" data-toggle="tab" data-target="#assetinfo" type="button" role="tab" aria-controls="assetinfo" aria-selected="true">General</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link " id="operations-tab" data-toggle="tab" data-target="#operations" type="button" role="tab" aria-controls="operations" aria-selected="false">Operations</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link " id="history-tab" data-toggle="tab" data-target="#history" type="button" role="tab" aria-controls="history" aria-selected="false">History</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link " id="definition-tab" data-toggle="tab" data-target="#defin" type="button" role="tab" aria-controls="defin" aria-selected="false">Definition</button>
                </li>
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                <div class="tab-pane active" id="assetinfo" role="tabpanel" aria-labelledby="assetinfo-tab">
                    <div class="card">
                        <div class="card-body">
                            <div class="container-fluid" style="margin-bottom: 5rem">

                                <form id="editFixedAssetForm">
                                    <div class="row justify-content-around">
                                        <div class="col-md-8 col-lg-8 col-xl-8 col-sm-12">
                                            <div class="row justify-content-around">
                                                <div class="col-sm-12">
                                                    <div class="row justify-content-around">
                                                        <form id="editCurrentAssetForm"> 
                                                            <div class="col-md-6 col-lg-6 col-xl-6 col-sm-4">   
                                                                <label for="fixedassetId">ID :</label>
                                                                <input type="number" id="fixedassetId" class="form-control" value="<?php echo $fixedasset->id;  ?>" disabled>
                                                            </div>
                                                            <div class="col-md-6 col-lg-6 col-xl-6 col-sm-4">
                                                                <label for="title">Title :</label>
                                                                <input type="text" id="title" class="form-control" data-bind="value:$root.currentAsset().title" enabled>
                                                            </div>
                                                            <div class="col-md-6 col-lg-6 col-xl-6 col-sm-4">
                                                                <label for="cost">Cost :</label>
                                                                <input type="number" id="cost" class="form-control" data-bind="value:$root.currentAsset().cost" enabled>
                                                            </div>
                                                            <div class="col-md-6 col-lg-6 col-xl-6 col-sm-4">
                                                                <label for="status">Status :</label>
                                                                <input type="text" id="status" class="form-control" data-bind="value:$root.currentAsset().status" disabled>
                                                            </div>
                                                            <div class="col-md-6 col-lg-6 col-xl-6 col-sm-4">
                                                                <label for="acqDate">Acquisition Date :</label>
                                                                <input type="date" id="acqDate" class="form-control" data-bind="value:$root.currentAsset().acquisitionDate" disabled>
                                                            </div>
                                                            <div class="col-md-6 col-lg-6 col-xl-6 col-sm-4">
                                                                <label for="location">Location :</label>
                                                                <input type="text" id="location" class="form-control" data-bind="value:$root.currentAsset().faLocation" enabled>
                                                            </div>
                                                            <div class="col-md-6 col-lg-6 col-xl-6 col-sm-4">
                                                                <label for="description">Description :</label>
                                                                <input type="text" id="description" class="form-control" data-bind="value:$root.currentAsset().description" enabled>
                                                            </div>
                                                            <div class="col-md-6 col-lg-6 col-xl-6 col-sm-4">
                                                                <label for="subCategory">Category : (<?php echo $fixedasset->subCategory; ?>)</label>
                                                                
                                                                <select name="subCategory_s" id="subCategory_s" class="form-control" data-bind="options:$root.subCategories,value:$root.currentAsset().subCategory,optionsValue:'id',optionsText:'title',optionsCaption:'Choose Category'" ></select> 
                                                            </div>
                                                            <div class="col-md-6 col-lg-6 col-xl-6 col-sm-4">
                                                                <label for="faGroup">Group :(<?php echo $fixedasset->faGroup; ?>)</label>
                                                                <select name="groups" id="faGroup" class="form-control" data-bind="options:$root.faGroups,value:$root.currentAsset().faGroup,optionsValue:'id',optionsText:'title',optionsCaption:'Choose Group'" ></select>
                                                            </div> 
                                                            <div class="col-md-6 col-lg-6 col-xl-6 col-sm-4">
                                                                <label for="depOn">Depreciates On :</label>
                                                                <input type="date" id="depOn" class="form-control" data-bind="value:$root.currentAsset().depreciatesOn" disabled>
                                                            </div>
                                                            
                                                            <div class="col-md-2 col-lg-2 col-xl-2 col-sm-2" style="margin-top: 2rem">
                                                                    <a id="resetFixedAsset" type="button" data-bind="click: resetCurrentAsset" target="_blank" class="btn btn-info"> Reset</a>
                                                            </div>
                                                            <div class="col-md-2 col-lg-2 col-xl-2 col-sm-2" style="margin-top: 2rem">
                                                                    <input id="editFixedAsset" type="submit" data-bind="click: submitEditAsset"  text="Save" class="btn btn-primary"> 
                                                            </div>
                                                        </form>



                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                  
                                </form>

                            </div> 
                        </div>
                    </div>
                </div>
                <div class="tab-pane " id="operations" role="tabpanel" aria-labelledby="operations-tab">
                    <div class="card">
                        <div class="card-body">
                            <div class="container-fluid" style="margin-bottom: 5rem">
                                <div class="row justify-content-around">
                      
                               <!-- <form id="transferAssetForm"> -->
                                    <div class="card border border-secondary col">
                                                    <div class="card-header">
                                                        Transfer Account
                                                    </div>
                                                    <div class="card-body">
                                                        <h5 class="card-title">Change Account for <?php echo $fixedasset->title; ?></h5>
                                                        <p class="card-text">
                                                            <div class="">
                                                                    <label for="fromAccount">From Account :</label>
                                                                    <input type="text" id="fromAccount" class="form-control"  value="<?php echo $fixedasset->accountNumber; ?>" disabled>
                                                            </div>
                                                            <div class="">
                                                                    <label for="toAccount">To Account :</label>
                                                                    <select name="toAccount" id="toAccount" class="form-control" data-bind="options:$root.accounts,value:$root.currentAsset().accountId,optionsValue:'id',optionsText:'title',optionsCaption:'Choose Account'" ></select>
                                                            </div>
                                                        </p>
                                                        <div class="" style="margin-top: 2rem">
                                                                    <input id="transferAsset" type="submit"  data-bind="click: transferAssetAccount" class="btn btn-info">  
                                                        </div>
                                                    </div>
                                    </div>
                                <!-- </form>   -->
                                  
                                <!-- <form id="manualDepreciationAssetForm"> -->
                                    <div class="card border border-secondary col">
                                                    <div class="card-header">
                                                        Manual Depreciation
                                                    </div>
                                                    <div class="card-body">
                                                        <h5 class="card-title">Manually depreciate <?php echo $fixedasset->title; ?></h5>
                                                        <p class="card-text">
                                                            <div class="">
                                                                    <label for="currentCost">Current Cost :</label>
                                                                    <input type="text" id="fromAccount" class="form-control"  data-bind="value:$root.originalAsset().cost()" disabled>
                                                            </div>                                                            
                                                            <div class="">
                                                                    <label for="depreciationAmount">Depreciation Amount :</label>
                                                                    <input type="text" id="depreciationAmount" class="form-control" data-bind="value:$root.depreciationAmount" enabled>
                                                            </div>
                                                            
                                                        </p>
                                                        <div class="" style="margin-top: 2rem">
                                                                    <input id="manualDepreciation" type="submit" data-bind="click: manualAssetDepreciation" class="btn btn-info"> 
                                                        </div>
                                                    </div>
                                    </div>
                                <!-- </form>     -->
                                </div>
                            </div> 
                        </div>
                    </div>
                </div>
                <div class="tab-pane " id="history" role="tabpanel" aria-labelledby="history-tab">
                    <div class="card">
                        <div class="card-body">
                            <div class="container-fluid" style="margin-bottom: 5rem">
                                <div class="row justify-content-around">
                                                        

                                
                                             <div id="fixedassets_table_container" class="col-12">
                                                <?php
                                                $table_columns = ['Account ', 'Start Date', 'End Date'];
                                                $table_properties = ["tableId" => "datatable_transfers", "title" => 'Fixed Asset Transfers', 'title-size' => 'h3'];
                                                include(APPROOT . '/views/partials/_datatable_full_generic.php');
                                                ?>
                                            </div> 
                                            <div id="fixedassets_table_container" class="col-12">
                                                <?php
                                                $table_columns = ['Asset ', 'Current Amount', 'Depreciation Amount', 'Depreciation Date'];
                                                $table_properties = ["tableId" => "datatable_depreciations", "title" => 'Fixed Asset Depreciations', 'title-size' => 'h3'];
                                                include(APPROOT . '/views/partials/_datatable_full_generic.php');
                                                ?>
                                            </div> 
                                    
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
                <div class="tab-pane " id="defin" role="tabpanel" aria-labelledby="definition-tab">
                    <div class="card">
                        <div class="card-body">
                            <div class="container-fluid" style="margin-bottom: 5rem">
                                <div class="row justify-content-around">
                                    <div class="card border border-secondary col">
                                        <div class="card-header">
                                            Define New Asset Sub Category
                                        </div>
                                        <div class="card-body">
                                            <p class="card-text">
                                            <div class="">
                                                <label for="subCateg">Sub Category :</label>
                                                <input type="text" id="subCateg" class="form-control"  data-bind="value:$root.newAssetCategory().title">
                                            </div>
                                            <div class="">
                                                <label for="categ">Category:</label>
                                                <select name="categ" id="categ" class="form-control" data-bind="options:$root.categories,value:$root.newAssetCategory().categoryId,optionsValue:'id',optionsText:'title',optionsCaption:'Choose Category'" ></select>
                                            </div>

                                            <div class="" style="margin-top: 2rem">
                                                <input id="addCateg" type="submit"  data-bind="click: addAssetCategory" class="btn btn-info">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card border border-secondary col">
                                        <div class="card-header">
                                            Define New Asset Group
                                        </div>
                                        <div class="card-body">
                                            <p class="card-text">
                                            <div class="">
                                                <label for="subCateg">Group Title :</label>
                                                <input type="text" id="subCateg" class="form-control"  data-bind="value:$root.newGroup">
                                            </div>

                                            <div class="" style="margin-top: 2rem">
                                                <input id="addGrp" type="submit"  data-bind="click: addAssetGroup" class="btn btn-info">
                                            </div>
                                        </div>
                                    </div>



                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            </div>
                


