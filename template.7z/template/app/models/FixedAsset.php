<?php

class FixedAsset
{
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }

    public function getAllFixedAssets()
    {
        $this->db->query('SELECT DISTINCT fa.id, fa.title, fa.cost,
                         CASE fa.active WHEN 1 THEN "Active" ELSE "Inactive" END AS status,
                         subcat.title AS subCategory, grp.title AS faGroup, facc.id AS accountId, facc.account_number accountNumber
                         FROM fixed_assets AS fa 
                         JOIN fixed_assets_subcategory AS subcat ON fa.sub_category = subcat.id
                         LEFT JOIN fixed_assets_group AS grp ON fa.fa_group = grp.id 
                         LEFT JOIN fixed_assets_accounts acc ON fa.id = acc.asset_id
                         LEFT JOIN accounts facc ON acc.account_id = facc.id
                         WHERE acc.end_date IS NULL
                        ');
        $fixedassets = $this->db->resultSet();
        return $fixedassets;
    }


    public function getFixedAsset($id)
    {
        $this->db->query('SELECT DISTINCT fa.id, fa.title, fa.cost,
        CASE fa.active WHEN 1 THEN "Active" ELSE "Inactive" END AS status,
        subcat.title AS subCategory, grp.title AS faGroup, fa.acquisition_date AS acquisitionDate,
        fa.fa_location AS faLocation, fa.description, fa.depreciates_on AS depreciatesOn, facc.id AS accountId, facc.account_number accountNumber
        FROM fixed_assets AS fa 
        JOIN fixed_assets_subcategory AS subcat ON fa.sub_category = subcat.id
        LEFT JOIN fixed_assets_group AS grp ON fa.fa_group = grp.id 
        LEFT JOIN fixed_assets_accounts acc ON fa.id = acc.asset_id
        LEFT JOIN accounts facc ON acc.account_id = facc.id
        WHERE fa.id = :id
        AND acc.end_date IS NULL
        '
        );
        $this->db->bind(':id', $id);
        $fixedasset = $this->db->single();
        return $fixedasset;
    }

    public function getAllsubCategories()
    {
        $this->db->query('SELECT id,title FROM fixed_assets_subcategory');
        $subCategories = $this->db->resultSet();
        return $subCategories;
    }

    public function getAllaccounts()
    {
        $this->db->query('SELECT DISTINCT id, account_number AS title FROM accounts');
        $accounts = $this->db->resultSet();
        return $accounts;
    }

    public function getAllgroups()
    {
        $this->db->query('SELECT id,title FROM fixed_assets_group');
        $groups = $this->db->resultSet();
        return $groups;
    }

    public function getAllcategories(){
         $this->db->query('SELECT id,title FROM fixed_assets_category');
         return $this->db->resultSet();
    }

    public function addFixedAsset($fixedasset)
    {
        $title = $fixedasset['title'];
        $cost = $fixedasset['cost'];
        $acquisitionDate = $fixedasset['acquisitionDate'];
        $faLocation = $fixedasset['faLocation'];
        $description = $fixedasset['description'];
        $subCategory = $fixedasset ['subCategory'];
        $faGroup = $fixedasset['faGroup'];
        $depreciatesOn = $fixedasset['depreciatesOn'];
        $accountId = $fixedasset['accountId'];

        $this->db->query('INSERT INTO `fixed_assets` (title, cost, acquisition_date, fa_location, description, sub_category, fa_group, depreciates_on)
                          VALUES (:title, :cost, :acquisitionDate, :faLocation, :description, :subCategory, :faGroup, :depreciatesOn)');
        $this->db->bind(':title', $title);
        $this->db->bind(':cost', $cost);
        $this->db->bind(':acquisitionDate', $acquisitionDate);
        $this->db->bind(':faLocation', $faLocation);
        $this->db->bind(':description', $description);
        $this->db->bind(':subCategory', $subCategory);
        $this->db->bind(':faGroup', $faGroup);
        $this->db->bind(':depreciatesOn', $depreciatesOn);
        if ($this->db->execute() == 1) {
            $this->db->query('INSERT INTO `fixed_assets_accounts` (asset_id, account_id) VALUES (LAST_INSERT_ID(), :accountId)');
            $this->db->bind(':accountId', $accountId);
            return $this->db->execute();
        }
        return 0;

    }
    public function addAssetCategory($assetcategory){
        $title = $assetcategory['title'];
        $categoryId = $assetcategory['categoryId'];

        $this->db->query(('INSERT INTO fixed_assets_subcategory(title,category_id)
                            VALUES (:title, :categoryId)'));
        $this->db->bind(':title',$title);
        $this->db->bind(':categoryId',$categoryId);
        return $this->db->execute();
    }

    public function  addAssetGroup($assetgroup){
        $group = $assetgroup['group'];
        $this->db->query('INSERT INTO fixed_assets_group(title)
                                VALUES (:title)');
        $this->db->bind(':title',$group);
        return $this->db->execute();
    }

    public function transferAssetAccount($fixedasset)
    {
        $assetID = $fixedasset['assetId'];
        $accountId = $fixedasset['accountId'];
        $this->db->query('UPDATE fixed_assets_accounts 
                          SET end_date = SYSDATE()
                          WHERE asset_id = :assetId');
        $this->db->bind(':assetId', $assetID);
        $this->db->execute();
        $this->db->query('INSERT INTO fixed_assets_accounts(asset_id, account_id)
                          VALUES (:assetId, :accountId)');
        $this->db->bind(':assetId', $assetID);
        $this->db->bind(':accountId', $accountId);
        return $this->db->execute();
    }

    public function manualAssetDepreciation($fixedasset)
    {
        $assetID = $fixedasset['assetId'];
        $originalCost = $fixedasset['originalCost'];
        $currentCost = $fixedasset['currentCost'];
        $depreciationAmount = $fixedasset['depreciationAmount'];
        $this->db->query('UPDATE fixed_assets
                          SET cost = :currentCost
                          WHERE id = :assetId');
        $this->db->bind(':currentCost', $currentCost);
        $this->db->bind(':assetId', $assetID);
        $this->db->execute();
        $this->db->query('INSERT INTO fixed_assets_depreciation(asset_id, current_amount, depreciation_amount, depreciation_date)
                          VALUES (:assetId, :currentCost,:depreciationAmount,SYSDATE())');
        $this->db->bind(':assetId', $assetID);
        $this->db->bind(':currentCost', $currentCost);
        $this->db->bind(':depreciationAmount', $depreciationAmount);
        return $this->db->execute();
    }


    public function updateFixedAsset($fixedasset)
    {

        $table = 'fixed_assets';
        $columns = $fixedasset;
        $primaryKeyName = 'id';
        $primaryKeyValue = $fixedasset['id'];
        unset($columns['id']);

        return $this->db->updateTable($table, $columns, $primaryKeyName, $primaryKeyValue);
    }


    public function deleteFixedAsset($id)
    {
        $this->db->query('DELETE FROM `fixed_assets` WHERE id = :id');
        $this->db->bind(':id', $id);
        $this->db->execute();
    }

    public function getAllAssetTransfers($fixedassetID)
    {
        $this->db->query('SELECT facc.account_number AS accountNumber,start_Date AS startDate, CASE WHEN end_date  IS NULL THEN "Still Active" ELSE end_date END AS endDate
                          FROM accounts facc
                          JOIN fixed_assets_accounts acc ON acc.account_id = facc.id 
                          WHERE asset_id = :asset_id');
        $this->db->bind(':asset_id', $fixedassetID);
        return $this->db->resultSet();

    }

    public function getAssetAccount($fixedassetID)
    {
        $this->db->query('SELECT id,facc.id AS accountId,facc.account_number AS accountNumber,start_Date AS startDate, CASE WHEN end_date  IS NULL THEN "Active" ELSE end_date END AS endDate
                          FROM accounts facc
                          JOIN fixed_assets_accounts acc ON acc.account_id = facc.id 
                          WHERE asset_id = :asset_id
                          AND end_date IS NULL');
        $this->db->bind(':asset_id', $fixedassetID);
        return $this->db->resultSet();

    }

    public function getAllAssetDepreciations($fixedassetID)
    {
        $this->db->query('SELECT asset_id AS assetId,current_amount AS currentAmount, depreciation_amount AS depreciationAmount, depreciation_date AS depreciationDate
                          FROM fixed_assets_depreciation
                          WHERE asset_id = :asset_id');
        $this->db->bind(':asset_id', $fixedassetID);
        return $this->db->resultSet();

    }


}